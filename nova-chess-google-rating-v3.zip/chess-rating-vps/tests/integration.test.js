const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { io: createClient } = require('socket.io-client');
const { buildApplication } = require('../src/app');

function once(socket, event, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      socket.off(event, handler);
      reject(new Error(`Timed out waiting for ${event}`));
    }, timeoutMs);
    const handler = (payload) => {
      clearTimeout(timeout);
      resolve(payload);
    };
    socket.once(event, handler);
  });
}

function emitAck(socket, event, payload = {}, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(`Timed out waiting for ack: ${event}`)), timeoutMs);
    socket.emit(event, payload, (response) => {
      clearTimeout(timeout);
      if (!response?.ok) {
        reject(new Error(`${response?.code || 'ERROR'}: ${response?.message || 'unknown error'}`));
        return;
      }
      resolve(response);
    });
  });
}

function cookieFrom(response) {
  const raw = response.headers.get('set-cookie');
  assert.ok(raw, 'session cookie should be set');
  return raw.split(';')[0];
}

async function bootstrap(baseUrl, cookie) {
  const response = await fetch(`${baseUrl}/api/bootstrap`, {
    headers: cookie ? { Cookie: cookie } : {},
  });
  assert.equal(response.status, 200);
  return { cookie: cookie || cookieFrom(response), data: await response.json() };
}

function connect(baseUrl, cookie) {
  return new Promise((resolve, reject) => {
    const socket = createClient(baseUrl, {
      transports: ['websocket'],
      extraHeaders: { Cookie: cookie },
      reconnection: false,
      forceNew: true,
    });
    socket.once('connect', () => resolve(socket));
    socket.once('connect_error', reject);
  });
}

test('Google-verified matchmaking, legal play, and Elo update', async (t) => {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nova-chess-test-'));
  const config = {
    host: '127.0.0.1',
    port: 0,
    nodeEnv: 'test',
    dataDir,
    trustProxy: 0,
    cookieSecure: false,
    sessionDays: 30,
    initialRating: 100,
    eloK: 32,
    ratingFloor: 0,
    gameMinutes: 10,
    gameIncrementSeconds: 0,
    inviteTtlMinutes: 30,
    siteName: 'NOVA CHESS TEST',
    googleClientId: 'test-client.apps.googleusercontent.com',
  };

  const application = buildApplication(config);
  await new Promise((resolve) => application.server.listen(0, '127.0.0.1', resolve));
  const port = application.server.address().port;
  const baseUrl = `http://127.0.0.1:${port}`;
  const sockets = [];

  t.after(async () => {
    for (const socket of sockets) socket.close();
    await application.close();
    fs.rmSync(dataDir, { recursive: true, force: true });
  });

  const sessionA = await bootstrap(baseUrl);
  const sessionB = await bootstrap(baseUrl);
  assert.equal(sessionA.data.me.rating, 100);
  assert.equal(sessionB.data.me.rating, 100);
  assert.equal(sessionA.data.me.isGuest, true);

  const guestSocket = await connect(baseUrl, sessionA.cookie);
  await assert.rejects(emitAck(guestSocket, 'match:queue'), /GOOGLE_AUTH_REQUIRED/);
  guestSocket.close();

  const invalidGoogleResponse = await fetch(`${baseUrl}/api/auth/google`, {
    method: 'POST',
    headers: {
      Cookie: sessionA.cookie,
      Origin: baseUrl,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ credential: 'x'.repeat(120) }),
  });
  assert.equal(invalidGoogleResponse.status, 401);
  assert.equal((await invalidGoogleResponse.json()).code, 'GOOGLE_TOKEN_INVALID');

  for (const [session, suffix] of [[sessionA, 'a'], [sessionB, 'b']]) {
    const user = application.db.getUserById(session.data.me.id);
    application.db.linkGoogleGuest({
      id: user.id,
      handle: user.handle,
      handleKey: user.handle_key,
      googleSub: `google-sub-${suffix}`,
      googleEmail: `player-${suffix}@gmail.com`,
      googleName: `Player ${suffix.toUpperCase()}`,
      googleLinkedAt: Date.now(),
      lastSeenAt: Date.now(),
    });
  }

  const verifiedA = await bootstrap(baseUrl, sessionA.cookie);
  const verifiedB = await bootstrap(baseUrl, sessionB.cookie);
  assert.equal(verifiedA.data.me.ratedEligible, true);
  assert.equal(verifiedB.data.me.ratedEligible, true);

  const socketA = await connect(baseUrl, sessionA.cookie);
  const socketB = await connect(baseUrl, sessionB.cookie);
  sockets.push(socketA, socketB);

  const gameAStarted = once(socketA, 'game:started');
  const gameBStarted = once(socketB, 'game:started');
  const queued = await emitAck(socketA, 'match:queue');
  assert.equal(queued.queued, true);
  const matched = await emitAck(socketB, 'match:queue');
  assert.equal(matched.matched, true);

  const [gameA, gameB] = await Promise.all([gameAStarted, gameBStarted]);
  assert.equal(gameA.id, gameB.id);
  assert.notEqual(gameA.color, gameB.color);

  const whiteSocket = gameA.color === 'white' ? socketA : socketB;
  const blackSocket = gameA.color === 'black' ? socketA : socketB;
  const whiteSession = gameA.color === 'white' ? sessionA : sessionB;
  const blackSession = gameA.color === 'black' ? sessionA : sessionB;
  const finishedPromise = once(whiteSocket, 'game:finished');

  await emitAck(whiteSocket, 'game:move', { gameId: gameA.id, from: 'f2', to: 'f3' });
  await emitAck(blackSocket, 'game:move', { gameId: gameA.id, from: 'e7', to: 'e5' });
  await emitAck(whiteSocket, 'game:move', { gameId: gameA.id, from: 'g2', to: 'g4' });
  await emitAck(blackSocket, 'game:move', { gameId: gameA.id, from: 'd8', to: 'h4' });

  const finished = await finishedPromise;
  assert.equal(finished.reason, 'checkmate');
  assert.equal(finished.result, '0-1');
  assert.equal(finished.black.ratingAfter, 116);
  assert.equal(finished.white.ratingAfter, 84);

  const whiteAfter = await bootstrap(baseUrl, whiteSession.cookie);
  const blackAfter = await bootstrap(baseUrl, blackSession.cookie);
  assert.equal(whiteAfter.data.me.rating, 84);
  assert.equal(blackAfter.data.me.rating, 116);
  assert.equal(blackAfter.data.me.wins, 1);
  assert.equal(whiteAfter.data.me.losses, 1);

  const leaderboard = await fetch(`${baseUrl}/api/leaderboard`, { headers: { Cookie: blackSession.cookie } }).then((response) => response.json());
  assert.equal(leaderboard.leaderboard.length, 2);
  assert.ok(leaderboard.leaderboard.every((player) => player.ratedEligible));
});
