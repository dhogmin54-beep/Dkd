const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { OAuth2Client } = require('google-auth-library');
const { randomId, sha256, parseCookies, now, cleanText } = require('./utils');

const scrypt = promisify(crypto.scrypt);
const SESSION_COOKIE = 'nova_chess_session';
const HANDLE_PATTERN = /^[\p{L}\p{N}_-]{3,20}$/u;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/u;
const GOOGLE_CSRF_COOKIE = 'g_csrf_token';

class AuthError extends Error {
  constructor(message, code = 'AUTH_ERROR', status = 400) {
    super(message);
    this.name = 'AuthError';
    this.code = code;
    this.status = status;
  }
}

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, 64, {
    N: 16384,
    r: 8,
    p: 1,
    maxmem: 64 * 1024 * 1024,
  });
  return `scrypt$16384$8$1$${salt.toString('base64url')}$${Buffer.from(key).toString('base64url')}`;
}

async function verifyPassword(password, stored) {
  try {
    const [algorithm, nRaw, rRaw, pRaw, saltRaw, hashRaw] = String(stored || '').split('$');
    if (algorithm !== 'scrypt') return false;
    const expected = Buffer.from(hashRaw, 'base64url');
    const actual = await scrypt(password, Buffer.from(saltRaw, 'base64url'), expected.length, {
      N: Number(nRaw),
      r: Number(rRaw),
      p: Number(pRaw),
      maxmem: 64 * 1024 * 1024,
    });
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

function normalizeHandle(value) {
  const handle = cleanText(value, 20);
  if (!HANDLE_PATTERN.test(handle)) {
    throw new AuthError('아이디는 3~20자의 한글·영문·숫자·_·-만 사용할 수 있습니다.', 'INVALID_HANDLE');
  }
  return { handle, key: handle.toLocaleLowerCase('en-US') };
}

function normalizeEmail(value) {
  const email = cleanText(value, 120).toLocaleLowerCase('en-US');
  if (!EMAIL_PATTERN.test(email)) {
    throw new AuthError('올바른 이메일 주소를 입력해 주세요.', 'INVALID_EMAIL');
  }
  return { email, key: email };
}

function validatePassword(value) {
  const password = String(value ?? '');
  if (password.length < 8 || password.length > 128) {
    throw new AuthError('비밀번호는 8~128자로 입력해 주세요.', 'INVALID_PASSWORD');
  }
  return password;
}

function createAuth({ db, config }) {
  const sessionMs = config.sessionDays * 24 * 60 * 60 * 1000;
  const googleClient = new OAuth2Client();

  function cookieValue(token, { clear = false } = {}) {
    const pieces = [
      `${SESSION_COOKIE}=${clear ? '' : encodeURIComponent(token)}`,
      'Path=/',
      'HttpOnly',
      config.cookieSecure ? 'SameSite=None' : 'SameSite=Lax',
      clear ? 'Max-Age=0' : `Max-Age=${Math.floor(sessionMs / 1000)}`,
    ];
    if (config.cookieSecure) pieces.push('Secure');
    return pieces.join('; ');
  }

  function sessionFromCookieHeader(header) {
    const token = parseCookies(header)[SESSION_COOKIE];
    if (!token || token.length < 20 || token.length > 200) return null;
    const tokenHash = sha256(token);
    const user = db.getUserBySessionHash(tokenHash);
    if (!user) return null;
    return { token, tokenHash, user };
  }

  function issueSession(userId) {
    const token = randomId(32);
    const tokenHash = sha256(token);
    db.createSession(tokenHash, userId, now() + sessionMs);
    return { token, tokenHash, cookie: cookieValue(token) };
  }

  function uniqueGuestHandle() {
    for (let attempt = 0; attempt < 12; attempt += 1) {
      const suffix = crypto.randomBytes(3).toString('hex').slice(0, 5).toUpperCase();
      const handle = `Guest-${suffix}`;
      if (!db.getUserByHandleKey(handle.toLocaleLowerCase('en-US'))) return handle;
    }
    return `Guest-${Date.now().toString(36).toUpperCase()}`;
  }

  function uniqueGoogleHandle(name, email) {
    const candidates = [name, String(email || '').split('@')[0], 'GooglePlayer'];
    let base = '';
    for (const candidate of candidates) {
      base = String(candidate || '')
        .normalize('NFKC')
        .replace(/\s+/gu, '_')
        .replace(/[^\p{L}\p{N}_-]/gu, '')
        .replace(/_+/g, '_')
        .replace(/^[_-]+|[_-]+$/g, '')
        .slice(0, 20);
      if (base.length >= 3) break;
    }
    if (base.length < 3) base = 'GooglePlayer';
    const baseKey = base.toLocaleLowerCase('en-US');
    if (!db.getUserByHandleKey(baseKey)) return { handle: base, handleKey: baseKey };

    for (let attempt = 0; attempt < 20; attempt += 1) {
      const suffix = crypto.randomBytes(2).toString('hex').toUpperCase();
      const handle = `${base.slice(0, 15)}-${suffix}`;
      const handleKey = handle.toLocaleLowerCase('en-US');
      if (!db.getUserByHandleKey(handleKey)) return { handle, handleKey };
    }
    const handle = `Google-${Date.now().toString(36).slice(-8)}`;
    return { handle, handleKey: handle.toLocaleLowerCase('en-US') };
  }

  function createGuestSession() {
    const user = db.createGuest(uniqueGuestHandle());
    const session = issueSession(user.id);
    return { user, session };
  }

  function getRequestSession(req) {
    return sessionFromCookieHeader(req.headers.cookie || '');
  }

  function ensureIdentity(req, res, next) {
    try {
      let session = getRequestSession(req);
      if (!session) {
        const created = createGuestSession();
        res.setHeader('Set-Cookie', created.session.cookie);
        session = {
          token: created.session.token,
          tokenHash: created.session.tokenHash,
          user: created.user,
        };
      } else if (now() - session.user.last_seen_at > 60_000) {
        db.touchUser(session.user.id);
      }
      req.auth = session;
      next();
    } catch (error) {
      next(error);
    }
  }

  async function linkGuest(user, currentTokenHash, input) {
    if (!user.is_guest) {
      throw new AuthError('이미 연동된 계정입니다.', 'ALREADY_LINKED', 409);
    }

    const { handle, key: handleKey } = normalizeHandle(input.handle);
    const { email, key: emailKey } = normalizeEmail(input.email);
    const password = validatePassword(input.password);

    const existingHandle = db.getUserByHandleKey(handleKey);
    if (existingHandle && existingHandle.id !== user.id) {
      throw new AuthError('이미 사용 중인 아이디입니다.', 'HANDLE_TAKEN', 409);
    }
    if (db.getUserByEmailKey(emailKey)) {
      throw new AuthError('이미 사용 중인 이메일입니다.', 'EMAIL_TAKEN', 409);
    }

    const passwordHash = await hashPassword(password);
    try {
      const result = db.linkGuest({
        id: user.id,
        handle,
        handleKey,
        email,
        emailKey,
        passwordHash,
        lastSeenAt: now(),
      });
      if (result.changes !== 1) {
        throw new AuthError('계정 연동 상태가 변경되었습니다. 새로고침 후 다시 시도해 주세요.', 'LINK_CONFLICT', 409);
      }
    } catch (error) {
      if (String(error.code || '').startsWith('SQLITE_CONSTRAINT')) {
        throw new AuthError('아이디 또는 이메일이 이미 사용 중입니다.', 'ACCOUNT_TAKEN', 409);
      }
      throw error;
    }

    db.deleteSession(currentTokenHash);
    const session = issueSession(user.id);
    return { user: db.getUserById(user.id), session };
  }

  async function login(input) {
    const identity = cleanText(input.identity, 120).toLocaleLowerCase('en-US');
    const password = validatePassword(input.password);
    const user = identity.includes('@')
      ? db.getUserByEmailKey(identity)
      : db.getUserByHandleKey(identity);

    if (!user || user.is_guest || !(await verifyPassword(password, user.password_hash))) {
      throw new AuthError('아이디/이메일 또는 비밀번호가 맞지 않습니다.', 'INVALID_CREDENTIALS', 401);
    }

    const session = issueSession(user.id);
    return { user, session };
  }

  async function verifyGoogleCredential(value) {
    if (!config.googleClientId) {
      throw new AuthError('Google 로그인이 아직 설정되지 않았습니다.', 'GOOGLE_NOT_CONFIGURED', 503);
    }
    const credential = String(value || '').trim();
    if (credential.length < 100 || credential.length > 8192) {
      throw new AuthError('Google 로그인 응답이 올바르지 않습니다.', 'INVALID_GOOGLE_CREDENTIAL', 400);
    }
    try {
      const ticket = await googleClient.verifyIdToken({
        idToken: credential,
        audience: config.googleClientId,
      });
      const payload = ticket.getPayload();
      const googleSub = String(payload?.sub || '').slice(0, 255);
      const googleEmail = cleanText(payload?.email, 254).toLocaleLowerCase('en-US');
      const googleName = cleanText(payload?.name, 120);
      if (!googleSub || !googleEmail || payload?.email_verified !== true) {
        throw new AuthError('확인된 Google 이메일 계정이 필요합니다.', 'GOOGLE_EMAIL_NOT_VERIFIED', 401);
      }
      return { googleSub, googleEmail, googleName: googleName || googleEmail.split('@')[0] };
    } catch (error) {
      if (error instanceof AuthError) throw error;
      throw new AuthError('Google 인증을 확인하지 못했습니다. 다시 로그인해 주세요.', 'GOOGLE_TOKEN_INVALID', 401);
    }
  }

  function verifyGoogleRedirectCsrf(cookieHeader, bodyToken) {
    const cookieToken = parseCookies(cookieHeader || '')[GOOGLE_CSRF_COOKIE];
    const submittedToken = String(bodyToken || '');
    if (!cookieToken || !submittedToken) {
      throw new AuthError('Google 로그인 보안 토큰이 없습니다.', 'GOOGLE_CSRF_MISSING', 400);
    }
    const cookieBuffer = Buffer.from(cookieToken);
    const submittedBuffer = Buffer.from(submittedToken);
    if (cookieBuffer.length !== submittedBuffer.length || !crypto.timingSafeEqual(cookieBuffer, submittedBuffer)) {
      throw new AuthError('Google 로그인 보안 토큰이 일치하지 않습니다.', 'GOOGLE_CSRF_INVALID', 400);
    }
  }

  async function googleLogin(user, currentTokenHash, credential) {
    const profile = await verifyGoogleCredential(credential);
    let target = db.getUserByGoogleSub(profile.googleSub);
    const timestamp = now();

    if (target) {
      db.updateGoogleProfile({
        id: target.id,
        googleSub: profile.googleSub,
        googleEmail: profile.googleEmail,
        googleName: profile.googleName,
        lastSeenAt: timestamp,
      });
      target = db.getUserById(target.id);
    } else if (user.google_sub) {
      throw new AuthError('다른 Google 계정으로 바꾸려면 먼저 로그아웃해 주세요.', 'GOOGLE_ACCOUNT_SWITCH_REQUIRES_LOGOUT', 409);
    } else if (user.is_guest) {
      const identity = uniqueGoogleHandle(profile.googleName, profile.googleEmail);
      try {
        const result = db.linkGoogleGuest({
          id: user.id,
          ...identity,
          googleSub: profile.googleSub,
          googleEmail: profile.googleEmail,
          googleName: profile.googleName,
          googleLinkedAt: timestamp,
          lastSeenAt: timestamp,
        });
        if (result.changes !== 1) throw new AuthError('계정 연결 상태가 변경되었습니다.', 'GOOGLE_LINK_CONFLICT', 409);
      } catch (error) {
        if (String(error.code || '').startsWith('SQLITE_CONSTRAINT')) {
          throw new AuthError('이미 연결된 Google 계정입니다.', 'GOOGLE_ACCOUNT_TAKEN', 409);
        }
        throw error;
      }
      target = db.getUserById(user.id);
    } else {
      try {
        const result = db.linkGoogleMember({
          id: user.id,
          googleSub: profile.googleSub,
          googleEmail: profile.googleEmail,
          googleName: profile.googleName,
          googleLinkedAt: timestamp,
          lastSeenAt: timestamp,
        });
        if (result.changes !== 1) throw new AuthError('Google 계정을 연결하지 못했습니다.', 'GOOGLE_LINK_CONFLICT', 409);
      } catch (error) {
        if (String(error.code || '').startsWith('SQLITE_CONSTRAINT')) {
          throw new AuthError('이미 연결된 Google 계정입니다.', 'GOOGLE_ACCOUNT_TAKEN', 409);
        }
        throw error;
      }
      target = db.getUserById(user.id);
    }

    if (currentTokenHash) db.deleteSession(currentTokenHash);
    const session = issueSession(target.id);
    return { user: target, session };
  }

  function logout(tokenHash) {
    if (tokenHash) db.deleteSession(tokenHash);
    return cookieValue('', { clear: true });
  }

  return {
    SESSION_COOKIE,
    ensureIdentity,
    getRequestSession,
    sessionFromCookieHeader,
    linkGuest,
    login,
    googleLogin,
    verifyGoogleRedirectCsrf,
    logout,
    publicUser: db.publicUser,
  };
}

module.exports = { createAuth, AuthError, hashPassword, verifyPassword };
