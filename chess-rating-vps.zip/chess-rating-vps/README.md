# NOVA CHESS

기본 레이팅 **100**부터 시작하는 VPS용 실시간 온라인 체스 웹사이트입니다. 처음 접속하면 자동으로 게스트 프로필과 세션이 생성되며, 플레이 중 쌓인 레이팅과 전적을 나중에 이메일·아이디·비밀번호 계정으로 그대로 연결할 수 있습니다.

## 포함된 기능

- 방문 즉시 `Guest-XXXXX` 프로필 생성, 시작 레이팅 100
- 게스트 기록을 잃지 않고 정식 계정으로 전환
- 기존 계정 로그인·로그아웃, scrypt 비밀번호 해시
- Socket.IO 기반 실시간 온라인 대국
- 서버에서 모든 수를 검증하는 표준 체스 규칙
- 10분 기본 시계, 시간패·기권·체크메이트·각종 무승부 처리
- 빠른 레이팅 매칭과 6자리 친구 초대 코드
- 초대 대전의 레이팅 반영 여부 선택
- Elo 레이팅 자동 계산, 순위표, 최근 대국 기록
- 새로고침·재접속·VPS 재시작 후 진행 중 대국 복구
- 모바일·태블릿·PC 반응형 다크 UI
- SQLite 영구 저장, Docker 볼륨, 백업·복원 스크립트
- Nginx WebSocket 프록시와 HTTPS 배포 설정
- 보안 헤더, HttpOnly/SameSite 쿠키, 요청 출처 검사, 로그인 속도 제한

## 가장 빠른 VPS 배포

Ubuntu VPS와 도메인이 준비되어 있다고 가정합니다. 도메인의 A 레코드를 VPS 공인 IP로 먼저 연결하세요.

### 1. Docker 설치

```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER"
newgrp docker
```

### 2. 프로젝트 설정

```bash
unzip chess-rating-vps.zip
cd chess-rating-vps
cp .env.example .env
nano .env
```

처음에는 아래처럼 둡니다.

```env
COOKIE_SECURE=false
SITE_NAME=NOVA CHESS
INITIAL_RATING=100
GAME_MINUTES=10
GAME_INCREMENT_SECONDS=0
```

### 3. 앱 실행

```bash
docker compose up -d --build
docker compose ps
curl http://127.0.0.1:3000/healthz
```

정상이라면 `{"ok":true,...}`가 표시됩니다. 앱 포트는 기본적으로 VPS 내부의 `127.0.0.1:3000`에만 열려 있어 외부에서 직접 접근할 수 없습니다. Nginx를 통해 공개하는 방식이 안전합니다.

### 4. Nginx 연결

```bash
sudo apt update
sudo apt install -y nginx
sudo cp nginx/nova-chess.conf /etc/nginx/sites-available/nova-chess
sudo sed -i 's/chess.example.com/실제도메인.example/g' /etc/nginx/sites-available/nova-chess
sudo ln -s /etc/nginx/sites-available/nova-chess /etc/nginx/sites-enabled/nova-chess
sudo nginx -t
sudo systemctl reload nginx
```

방화벽을 사용한다면 SSH, HTTP, HTTPS만 허용합니다.

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### 5. 무료 HTTPS 인증서

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d 실제도메인.example
```

HTTPS가 정상 작동한 다음 `.env`를 수정합니다.

```env
COOKIE_SECURE=true
```

설정을 반영합니다.

```bash
docker compose up -d
```

이제 `https://실제도메인.example`에서 접속할 수 있습니다. Socket.IO용 WebSocket 헤더와 장시간 연결 설정은 제공된 Nginx 파일에 이미 포함되어 있습니다.

## 레이팅 규칙

모든 새 프로필은 `INITIAL_RATING=100`으로 시작합니다. 빠른 매칭은 항상 레이팅 대전이며, 친구 초대 대전은 생성할 때 레이팅 반영 여부를 선택할 수 있습니다.

기본 Elo K값은 32입니다.

```text
기대 승률 = 1 / (1 + 10 ^ ((상대 레이팅 - 내 레이팅) / 400))
새 레이팅 = 기존 레이팅 + K × (실제 점수 - 기대 승률)
```

승리는 1점, 무승부는 0.5점, 패배는 0점으로 계산합니다. 기본 최저 레이팅은 0이며 `RATING_FLOOR`로 바꿀 수 있습니다.

## 계정 동작

첫 접속 시 서버가 게스트 사용자와 30일 세션 쿠키를 만듭니다. 게스트 상태에서도 레이팅과 전적은 데이터베이스에 저장됩니다.

`현재 기록을 계정에 연결`에서 아이디, 이메일, 비밀번호를 등록하면 같은 사용자 ID를 유지한 채 정식 계정으로 전환됩니다. 따라서 기존 레이팅, 승패, 기보가 사라지지 않습니다. 게스트가 계정 연결 전에 브라우저 쿠키를 지우면 해당 게스트 프로필에 다시 접근할 방법이 없으므로 운영 화면에서 계정 연결을 권장합니다.

## 환경 변수

| 변수 | 기본값 | 설명 |
|---|---:|---|
| `HOST_PORT` | `3000` | Docker가 VPS 내부에 바인딩할 포트 |
| `COOKIE_SECURE` | `false` | HTTPS 적용 후 반드시 `true` 권장 |
| `SESSION_DAYS` | `30` | 로그인 세션 유지 일수 |
| `INITIAL_RATING` | `100` | 신규 프로필 시작 레이팅 |
| `ELO_K` | `32` | Elo 변동 계수 |
| `RATING_FLOOR` | `0` | 레이팅 최저값 |
| `GAME_MINUTES` | `10` | 기본 제한 시간(분) |
| `GAME_INCREMENT_SECONDS` | `0` | 매 수 후 추가 시간(초) |
| `INVITE_TTL_MINUTES` | `30` | 초대 코드 유효 시간 |
| `SITE_NAME` | `NOVA CHESS` | 웹사이트 표시 이름 |
| `TRUST_PROXY` | `1` | Nginx 한 단계를 신뢰하도록 설정 |

환경 변수 변경 후 다음 명령으로 컨테이너를 재생성합니다.

```bash
docker compose up -d
```

## 데이터와 백업

SQLite 파일은 Docker named volume `nova_chess_data`에 저장됩니다. 컨테이너를 삭제해도 볼륨을 직접 삭제하지 않는 한 데이터가 유지됩니다.

백업 시 앱을 잠시 정상 종료한 뒤 데이터 볼륨 전체를 압축합니다.

```bash
./scripts/backup.sh
```

결과 파일은 `backups/nova-chess-YYYYMMDD-HHMMSS.tar.gz`에 생성됩니다.

복원은 현재 데이터를 교체하므로 먼저 별도 백업을 만든 후 실행하세요.

```bash
./scripts/restore.sh backups/nova-chess-20260709-120000.tar.gz
```

자동 일일 백업 예시:

```bash
crontab -e
```

```cron
15 4 * * * cd /opt/nova-chess && ./scripts/backup.sh >> /var/log/nova-chess-backup.log 2>&1
```

오래된 백업은 별도 스토리지로 복사하거나 보존 기간에 맞춰 정리하세요.

## 업데이트

업데이트 전 백업한 뒤 새 파일로 교체하고 이미지를 다시 빌드합니다.

```bash
./scripts/backup.sh
docker compose up -d --build
docker compose logs -f --tail=100 app
```

상태 확인:

```bash
docker compose ps
curl http://127.0.0.1:3000/healthz
```

## Docker 없이 systemd로 실행

Node.js 24 LTS와 npm이 설치된 VPS에서는 직접 실행할 수도 있습니다.

```bash
sudo useradd --system --home /opt/nova-chess --shell /usr/sbin/nologin nova-chess
sudo mkdir -p /opt/nova-chess
sudo cp -a . /opt/nova-chess/
cd /opt/nova-chess
sudo npm ci --omit=dev --ignore-scripts
sudo mkdir -p data
sudo chown -R nova-chess:nova-chess /opt/nova-chess
sudo cp systemd/nova-chess.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now nova-chess
sudo systemctl status nova-chess
```

이 경우 `.env`의 `DATA_DIR`을 `/opt/nova-chess/data`, `HOST`를 `127.0.0.1`, `PORT`를 `3000`으로 설정하세요. Nginx 설정은 Docker 방식과 동일하게 사용할 수 있습니다.

## 개발과 테스트

Node.js 24 LTS 권장:

```bash
npm install
npm run check
npm test
npm run dev
```

자동 테스트는 다음을 실제로 검증합니다.

- 서로 다른 두 게스트 세션 생성
- Socket.IO 빠른 매칭
- 서버의 합법 수 검증
- Fool's Mate 체크메이트 완료
- 100에서 116/84로 Elo 반영
- 승패 및 최근 대국 저장
- 승자 게스트를 정식 계정으로 연결
- 새 세션에서 다시 로그인해 레이팅 복원

## 프로젝트 구조

```text
public/                 브라우저 UI, 체스 보드, 반응형 디자인
src/app.js              Express·Socket.IO 앱과 API
src/auth.js             게스트 세션, 계정 연결, 로그인
src/db.js               SQLite 스키마와 데이터 접근
src/game-manager.js     매칭, 초대, 체스 규칙, 시계, 결과 처리
src/rating.js           Elo 계산
tests/                  단위·통합 테스트
nginx/                  VPS 리버스 프록시 설정
systemd/                Docker 미사용 시 서비스 파일
scripts/                백업·복원 도구
```

## 운영 시 알아둘 점

이 구성은 **한 대의 VPS, 한 개의 앱 프로세스**에 맞춰져 있습니다. 실시간 매칭 대기열과 연결 상태는 메모리에 있고 대국·레이팅·계정은 SQLite에 영구 저장됩니다. 동일 앱을 여러 인스턴스로 수평 확장하려면 Redis 기반 Socket.IO 어댑터, 공유 매칭 큐, PostgreSQL 같은 외부 데이터베이스가 추가로 필요합니다.

현재 버전에는 이메일 인증, 비밀번호 재설정 메일, 관리자 화면, 엔진 기반 부정행위 탐지 기능은 포함되지 않았습니다. 공개 커뮤니티 규모로 운영할 경우 이용약관·개인정보 처리방침, 신고/제재 기능, 이메일 인증, 관리자 도구, 모니터링을 추가하는 것이 좋습니다.

HTTPS 없이 `COOKIE_SECURE=true`를 설정하면 브라우저가 세션 쿠키를 보내지 않습니다. 먼저 HTTPS를 확인한 뒤 값을 바꾸세요.

## 라이선스

MIT License. 자유롭게 이름, 색상, 로고, 레이팅 규칙과 기능을 수정해 사용할 수 있습니다.
