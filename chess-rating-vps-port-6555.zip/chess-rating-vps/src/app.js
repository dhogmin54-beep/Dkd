const path = require('node:path');
const http = require('node:http');
const express = require('express');
const { Server } = require('socket.io');
const { createDatabase } = require('./db');
const { createAuth, AuthError } = require('./auth');
const { createGameManager } = require('./game-manager');

function createRateLimiter({ windowMs = 10 * 60_000, max = 20 } = {}) {
  const buckets = new Map();
  const cleanup = setInterval(() => {
    const timestamp = Date.now();
    for (const [key, bucket] of buckets) {
      if (bucket.resetAt <= timestamp) buckets.delete(key);
    }
  }, Math.min(windowMs, 60_000));
  cleanup.unref?.();

  const middleware = (req, res, next) => {
    const key = `${req.ip}:${req.path}`;
    const timestamp = Date.now();
    let bucket = buckets.get(key);
    if (!bucket || bucket.resetAt <= timestamp) {
      bucket = { count: 0, resetAt: timestamp + windowMs };
      buckets.set(key, bucket);
    }
    bucket.count += 1;
    res.setHeader('X-RateLimit-Limit', String(max));
    res.setHeader('X-RateLimit-Remaining', String(Math.max(0, max - bucket.count)));
    if (bucket.count > max) {
      res.status(429).json({
        ok: false,
        code: 'RATE_LIMITED',
        message: '요청이 너무 많습니다. 잠시 후 다시 시도해 주세요.',
      });
      return;
    }
    next();
  };

  middleware.close = () => clearInterval(cleanup);
  return middleware;
}

function buildApplication(config) {
  const db = createDatabase(config);
  const app = express();
  const server = http.createServer(app);
  const io = new Server(server, {
    serveClient: true,
    maxHttpBufferSize: 64 * 1024,
    pingTimeout: 20_000,
    pingInterval: 25_000,
    transports: ['polling', 'websocket'],
  });
  const auth = createAuth({ db, config });
  const gameManager = createGameManager({ io, db, config });
  const authLimiter = createRateLimiter({ windowMs: 10 * 60_000, max: 15 });

  app.disable('x-powered-by');
  if (config.trustProxy > 0) app.set('trust proxy', config.trustProxy);

  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    if (config.cookieSecure) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'",
    );
    next();
  });

  app.use((req, res, next) => {
    if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
      const origin = req.get('origin');
      if (origin) {
        try {
          if (new URL(origin).host !== req.get('host')) {
            res.status(403).json({ ok: false, code: 'ORIGIN_REJECTED', message: '허용되지 않은 요청 출처입니다.' });
            return;
          }
        } catch {
          res.status(403).json({ ok: false, code: 'ORIGIN_REJECTED', message: '허용되지 않은 요청 출처입니다.' });
          return;
        }
      }
    }
    next();
  });

  app.use(express.json({ limit: '32kb', strict: true }));

  app.get('/healthz', (_req, res) => {
    res.json({ ok: true, service: 'nova-chess', time: Date.now() });
  });

  app.get('/api/bootstrap', auth.ensureIdentity, (req, res) => {
    const user = db.getUserById(req.auth.user.id);
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ok: true,
      site: {
        name: config.siteName,
        initialRating: config.initialRating,
        gameMinutes: config.gameMinutes,
        incrementSeconds: config.gameIncrementSeconds,
      },
      me: db.publicUser(user),
      activeGame: gameManager.getActiveStateForUser(user.id),
      leaderboard: db.leaderboard(10),
      recentGames: db.recentGames(user.id, 8),
      lobby: gameManager.getLobbyStats(),
    });
  });

  app.get('/api/leaderboard', auth.ensureIdentity, (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, leaderboard: db.leaderboard(50) });
  });

  app.get('/api/games/:gameId', auth.ensureIdentity, (req, res) => {
    const game = gameManager.getGameForUser(String(req.params.gameId || ''), req.auth.user.id);
    if (!game) {
      res.status(404).json({ ok: false, code: 'GAME_NOT_FOUND', message: '대국을 찾을 수 없습니다.' });
      return;
    }
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, game });
  });

  app.post('/api/auth/link', authLimiter, auth.ensureIdentity, async (req, res, next) => {
    try {
      const linked = await auth.linkGuest(req.auth.user, req.auth.tokenHash, req.body || {});
      res.setHeader('Set-Cookie', linked.session.cookie);
      res.json({ ok: true, me: db.publicUser(linked.user) });
    } catch (error) {
      next(error);
    }
  });

  app.post('/api/auth/login', authLimiter, async (req, res, next) => {
    try {
      const previous = auth.getRequestSession(req);
      if (previous && gameManager.getActiveStateForUser(previous.user.id)) {
        throw new AuthError('진행 중인 대국이 끝난 뒤 다른 계정으로 로그인해 주세요.', 'ACTIVE_GAME', 409);
      }
      const loggedIn = await auth.login(req.body || {});
      if (previous) db.deleteSession(previous.tokenHash);
      res.setHeader('Set-Cookie', loggedIn.session.cookie);
      res.json({ ok: true, me: db.publicUser(loggedIn.user) });
    } catch (error) {
      next(error);
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    const session = auth.getRequestSession(req);
    if (session && gameManager.getActiveStateForUser(session.user.id)) {
      res.status(409).json({ ok: false, code: 'ACTIVE_GAME', message: '진행 중인 대국이 끝난 뒤 로그아웃해 주세요.' });
      return;
    }
    res.setHeader('Set-Cookie', auth.logout(session?.tokenHash));
    res.json({ ok: true });
  });

  io.use((socket, next) => {
    const origin = socket.handshake.headers.origin;
    const host = socket.handshake.headers.host;
    if (origin) {
      try {
        if (new URL(origin).host !== host) {
          const error = new Error('허용되지 않은 연결 출처입니다.');
          error.data = { code: 'ORIGIN_REJECTED' };
          next(error);
          return;
        }
      } catch {
        const error = new Error('허용되지 않은 연결 출처입니다.');
        error.data = { code: 'ORIGIN_REJECTED' };
        next(error);
        return;
      }
    }
    const session = auth.sessionFromCookieHeader(socket.handshake.headers.cookie || '');
    if (!session) {
      const error = new Error('세션이 만료되었습니다. 페이지를 새로고침해 주세요.');
      error.data = { code: 'SESSION_REQUIRED' };
      next(error);
      return;
    }
    socket.user = session.user;
    socket.sessionTokenHash = session.tokenHash;
    next();
  });

  io.on('connection', (socket) => {
    gameManager.handleSocket(socket);
  });

  const publicDir = path.join(__dirname, '..', 'public');
  app.use(express.static(publicDir, {
    etag: true,
    maxAge: config.nodeEnv === 'production' ? '1h' : 0,
    setHeaders(res, filePath) {
      if (filePath.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
    },
  }));

  app.use((req, res, next) => {
    if (req.method === 'GET' && req.accepts('html')) {
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(path.join(publicDir, 'index.html'));
      return;
    }
    next();
  });

  app.use((error, _req, res, _next) => {
    if (error instanceof AuthError) {
      res.status(error.status).json({ ok: false, code: error.code, message: error.message });
      return;
    }
    if (error?.type === 'entity.too.large') {
      res.status(413).json({ ok: false, code: 'PAYLOAD_TOO_LARGE', message: '요청 데이터가 너무 큽니다.' });
      return;
    }
    if (error instanceof SyntaxError && 'body' in error) {
      res.status(400).json({ ok: false, code: 'INVALID_JSON', message: '요청 형식이 올바르지 않습니다.' });
      return;
    }
    console.error(error);
    res.status(500).json({ ok: false, code: 'SERVER_ERROR', message: '서버 오류가 발생했습니다.' });
  });

  async function close() {
    authLimiter.close();
    gameManager.close();
    await new Promise((resolve) => io.close(resolve));
    if (server.listening) await new Promise((resolve) => server.close(resolve));
    db.close();
  }

  return { app, server, io, db, auth, gameManager, close };
}

module.exports = { buildApplication };
