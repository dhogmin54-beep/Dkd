const test = require('node:test');
const assert = require('node:assert/strict');
const { expectedScore, calculateElo } = require('../src/rating');

test('equal ratings have an expected score of 0.5', () => {
  assert.equal(expectedScore(100, 100), 0.5);
});

test('winner gains and loser loses 16 points at K=32', () => {
  const result = calculateElo(100, 100, 1, { k: 32, floor: 0 });
  assert.deepEqual(result, {
    ratingA: 116,
    ratingB: 84,
    deltaA: 16,
    deltaB: -16,
  });
});

test('rating changes remain zero-sum before a floor is applied', () => {
  const result = calculateElo(137, 284, 0.5, { k: 32, floor: 0 });
  assert.equal(result.deltaA + result.deltaB, 0);
});

test('rating floor is respected and reports the actual delta', () => {
  const result = calculateElo(0, 2000, 0, { k: 32, floor: 0 });
  assert.equal(result.ratingA, 0);
  assert.equal(result.deltaA, 0);
});
