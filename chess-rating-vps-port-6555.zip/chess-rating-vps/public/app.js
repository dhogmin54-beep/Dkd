(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const elements = {
    loadingView: $('loadingView'),
    lobbyView: $('lobbyView'),
    gameView: $('gameView'),
    siteName: $('siteName'),
    onlineCount: $('onlineCount'),
    accountButton: $('accountButton'),
    accountAvatar: $('accountAvatar'),
    accountHandle: $('accountHandle'),
    accountRating: $('accountRating'),
    brandButton: $('brandButton'),
    gameLogoButton: $('gameLogoButton'),
    quickMatchButton: $('quickMatchButton'),
    openInviteButton: $('openInviteButton'),
    profileAccountAction: $('profileAccountAction'),
    profileTypeBadge: $('profileTypeBadge'),
    profileAvatar: $('profileAvatar'),
    profileHandle: $('profileHandle'),
    profileRating: $('profileRating'),
    profileRecord: $('profileRecord'),
    profileGames: $('profileGames'),
    profileRatedGames: $('profileRatedGames'),
    profileWinRate: $('profileWinRate'),
    guestNotice: $('guestNotice'),
    heroOnline: $('heroOnline'),
    activeGameCount: $('activeGameCount'),
    searchingCount: $('searchingCount'),
    timeControlLabel: $('timeControlLabel'),
    leaderboardList: $('leaderboardList'),
    recentGamesList: $('recentGamesList'),
    refreshLeaderboardButton: $('refreshLeaderboardButton'),
    queueOverlay: $('queueOverlay'),
    queueTime: $('queueTime'),
    cancelQueueButton: $('cancelQueueButton'),
    modalRoot: $('modalRoot'),
    modalBackdrop: $('modalBackdrop'),
    modalPanel: $('modalPanel'),
    modalContent: $('modalContent'),
    modalCloseButton: $('modalCloseButton'),
    promotionOverlay: $('promotionOverlay'),
    promotionChoices: $('promotionChoices'),
    toastRegion: $('toastRegion'),
    connectionBanner: $('connectionBanner'),
    gameTitle: $('gameTitle'),
    gameRatedBadge: $('gameRatedBadge'),
    gameConnectionBadge: $('gameConnectionBadge'),
    opponentPanel: $('opponentPanel'),
    myPanel: $('myPanel'),
    chessBoard: $('chessBoard'),
    turnStatus: $('turnStatus'),
    turnDetail: $('turnDetail'),
    moveList: $('moveList'),
    moveCount: $('moveCount'),
    drawOfferBox: $('drawOfferBox'),
    offerDrawButton: $('offerDrawButton'),
    acceptDrawButton: $('acceptDrawButton'),
    declineDrawButton: $('declineDrawButton'),
    resignButton: $('resignButton'),
    gameIdLabel: $('gameIdLabel'),
    gameModeLabel: $('gameModeLabel'),
    currentYear: $('currentYear'),
  };

  const state = {
    site: null,
    me: null,
    leaderboard: [],
    recentGames: [],
    lobby: { online: 0, searching: 0, activeGames: 0 },
    socket: null,
    connected: false,
    game: null,
    finishedGame: null,
    selectedSquare: null,
    moving: false,
    queueing: false,
    queueStartedAt: 0,
    queueTimer: null,
    clockTimer: null,
    modalOnClose: null,
    modalLocked: false,
    pendingPromotion: null,
    inviteCode: null,
  };

  const PIECES = {
    P: '♙', N: '♘', B: '♗', R: '♖', Q: '♕', K: '♔',
    p: '♟', n: '♞', b: '♝', r: '♜', q: '♛', k: '♚',
  };
  const PROMOTION_PIECES = {
    white: { q: '♕', r: '♖', b: '♗', n: '♘' },
    black: { q: '♛', r: '♜', b: '♝', n: '♞' },
  };

  const REASON_LABELS = {
    checkmate: '체크메이트',
    resignation: '기권',
    timeout: '시간 종료',
    stalemate: '스테일메이트',
    threefold_repetition: '3회 동형 반복',
    insufficient_material: '기물 부족',
    fifty_move_rule: '50수 규칙',
    draw_agreement: '합의 무승부',
    draw: '무승부',
    restore_error: '서버 복구 오류',
  };

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function initial(value) {
    return [...String(value || 'G').trim()][0]?.toUpperCase() || 'G';
  }

  function formatNumber(value) {
    return new Intl.NumberFormat('ko-KR').format(Number(value || 0));
  }

  function formatDate(timestamp) {
    if (!timestamp) return '';
    return new Intl.DateTimeFormat('ko-KR', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(timestamp));
  }

  function formatClock(milliseconds) {
    const safe = Math.max(0, Number(milliseconds || 0));
    const totalSeconds = Math.ceil(safe / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastRegion.appendChild(toast);
    window.setTimeout(() => toast.remove(), 3400);
  }

  async function api(path, options = {}) {
    const init = {
      method: options.method || 'GET',
      credentials: 'same-origin',
      headers: { ...(options.headers || {}) },
    };
    if (options.body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(options.body);
    }

    const response = await fetch(path, init);
    let data;
    try {
      data = await response.json();
    } catch {
      data = { ok: false, message: '서버 응답을 읽을 수 없습니다.' };
    }
    if (!response.ok || data.ok === false) {
      const error = new Error(data.message || '요청을 처리하지 못했습니다.');
      error.code = data.code || 'REQUEST_FAILED';
      error.status = response.status;
      throw error;
    }
    return data;
  }

  function emitAck(eventName, payload = {}) {
    return new Promise((resolve, reject) => {
      if (!state.socket?.connected) {
        reject(new Error('서버에 연결되어 있지 않습니다.'));
        return;
      }
      const timeout = window.setTimeout(() => reject(new Error('서버 응답 시간이 초과되었습니다.')), 9000);
      state.socket.emit(eventName, payload, (response) => {
        window.clearTimeout(timeout);
        if (!response?.ok) {
          const error = new Error(response?.message || '요청을 처리하지 못했습니다.');
          error.code = response?.code || 'SOCKET_ERROR';
          reject(error);
          return;
        }
        resolve(response);
      });
    });
  }

  function applyBootstrap(data, { preserveGame = false } = {}) {
    state.site = data.site;
    state.me = data.me;
    state.leaderboard = data.leaderboard || [];
    state.recentGames = data.recentGames || [];
    state.lobby = data.lobby || state.lobby;
    if (!preserveGame) state.game = data.activeGame || null;

    document.title = state.site?.name || 'NOVA CHESS';
    elements.siteName.textContent = state.site?.name || 'NOVA CHESS';
    elements.timeControlLabel.textContent = `${state.site?.gameMinutes || 10}분${state.site?.incrementSeconds ? ` + ${state.site.incrementSeconds}초` : ''} · 레이팅 반영`;
    renderAll();
  }

  async function loadBootstrap() {
    try {
      const data = await api('/api/bootstrap');
      applyBootstrap(data);
      connectSocket();
    } catch (error) {
      elements.loadingView.innerHTML = '';
      const box = document.createElement('div');
      box.className = 'empty-state';
      box.innerHTML = '<span>♞</span><strong>서버에 연결하지 못했습니다</strong>';
      const detail = document.createElement('p');
      detail.textContent = error.message;
      box.appendChild(detail);
      elements.loadingView.appendChild(box);
      showToast(error.message, 'error');
    }
  }

  function connectSocket() {
    if (state.socket) state.socket.disconnect();
    state.socket = window.io({
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 700,
      reconnectionDelayMax: 5000,
    });

    state.socket.on('connect', () => {
      state.connected = true;
      elements.connectionBanner.hidden = true;
      updateConnectionUi();
      if (state.game?.status === 'active') {
        emitAck('game:sync', { gameId: state.game.id })
          .then((response) => handleGameState(response.game))
          .catch(() => {});
      }
    });

    state.socket.on('disconnect', () => {
      state.connected = false;
      elements.connectionBanner.hidden = false;
      updateConnectionUi();
    });

    state.socket.on('connect_error', (error) => {
      state.connected = false;
      elements.connectionBanner.hidden = false;
      elements.connectionBanner.textContent = error?.message || '서버와 다시 연결하는 중입니다…';
      updateConnectionUi();
    });

    state.socket.on('lobby:stats', (lobby) => {
      state.lobby = lobby;
      renderLobbyStats();
    });

    state.socket.on('game:started', handleGameState);
    state.socket.on('game:state', handleGameState);

    state.socket.on('game:clock', (clock) => {
      if (!state.game || state.game.id !== clock.gameId || state.game.status !== 'active') return;
      state.game.turn = clock.turn;
      state.game.clocks = {
        ...(state.game.clocks || {}),
        whiteMs: clock.whiteMs,
        blackMs: clock.blackMs,
        serverNow: clock.serverNow,
      };
      renderClockValues();
      renderGameStatus();
    });

    state.socket.on('game:finished', handleGameFinished);
    state.socket.on('game:notice', (notice) => showToast(notice.message, 'info'));
    state.socket.on('leaderboard:changed', () => {
      window.setTimeout(() => refreshDashboardData({ preserveGame: Boolean(state.game) }), 250);
    });
  }

  function updateConnectionUi() {
    if (!elements.gameConnectionBadge) return;
    elements.gameConnectionBadge.classList.toggle('connected', state.connected);
    elements.gameConnectionBadge.innerHTML = state.connected ? '<i></i> LIVE' : '<i></i> OFFLINE';
  }

  async function refreshDashboardData({ preserveGame = false } = {}) {
    try {
      const data = await api('/api/bootstrap');
      applyBootstrap(data, { preserveGame });
    } catch (error) {
      showToast(error.message, 'error');
    }
  }

  function renderAll() {
    elements.loadingView.hidden = true;
    renderHeader();
    renderProfile();
    renderLobbyStats();
    renderLeaderboard();
    renderRecentGames();
    if (state.game) renderGame();
    else showLobby();
  }

  function renderHeader() {
    if (!state.me) return;
    const avatar = initial(state.me.handle);
    elements.accountAvatar.textContent = avatar;
    elements.accountHandle.textContent = state.me.handle;
    elements.accountRating.textContent = formatNumber(state.me.rating);
  }

  function renderProfile() {
    if (!state.me) return;
    const games = Number(state.me.gamesPlayed || 0);
    const winRate = games > 0 ? Math.round((Number(state.me.wins || 0) / games) * 100) : 0;
    elements.profileTypeBadge.textContent = state.me.isGuest ? 'GUEST' : 'MEMBER';
    elements.profileAvatar.textContent = initial(state.me.handle);
    elements.profileHandle.textContent = state.me.handle;
    elements.profileRating.textContent = formatNumber(state.me.rating);
    elements.profileRecord.textContent = `${state.me.wins}승 ${state.me.draws}무 ${state.me.losses}패`;
    elements.profileGames.textContent = formatNumber(games);
    elements.profileRatedGames.textContent = formatNumber(state.me.ratedGames);
    elements.profileWinRate.textContent = `${winRate}%`;
    elements.profileAccountAction.textContent = state.me.isGuest ? '현재 기록을 계정에 연결' : '계정 정보 보기';
    elements.guestNotice.hidden = !state.me.isGuest;
  }

  function renderLobbyStats() {
    const lobby = state.lobby || {};
    const online = Number(lobby.online || 0);
    elements.onlineCount.textContent = formatNumber(online);
    elements.heroOnline.textContent = formatNumber(online);
    elements.activeGameCount.textContent = formatNumber(lobby.activeGames || 0);
    elements.searchingCount.textContent = formatNumber(lobby.searching || 0);
  }

  function renderLeaderboard() {
    elements.leaderboardList.textContent = '';
    if (!state.leaderboard.length) {
      elements.leaderboardList.innerHTML = '<div class="empty-state"><span>♛</span><strong>아직 순위가 없습니다</strong><p>첫 레이팅 대국을 완료하면 이곳에 이름이 올라갑니다.</p></div>';
      return;
    }

    state.leaderboard.forEach((player, index) => {
      const row = document.createElement('div');
      row.className = `leaderboard-row${player.id === state.me?.id ? ' is-me' : ''}`;
      const rank = document.createElement('span');
      rank.className = `rank-number${index < 3 ? ' top-rank' : ''}`;
      rank.textContent = String(index + 1).padStart(2, '0');

      const avatar = document.createElement('span');
      avatar.className = 'avatar rank-avatar';
      avatar.textContent = initial(player.handle);

      const copy = document.createElement('div');
      copy.className = 'rank-copy';
      const handle = document.createElement('strong');
      handle.textContent = player.handle;
      const record = document.createElement('small');
      record.textContent = `${player.wins}승 ${player.draws}무 ${player.losses}패${player.isGuest ? ' · GUEST' : ''}`;
      copy.append(handle, record);

      const rating = document.createElement('span');
      rating.className = 'rank-rating';
      rating.textContent = `${formatNumber(player.rating)} RP`;
      row.append(rank, avatar, copy, rating);
      elements.leaderboardList.appendChild(row);
    });
  }

  function renderRecentGames() {
    elements.recentGamesList.textContent = '';
    if (!state.recentGames.length) {
      elements.recentGamesList.innerHTML = '<div class="empty-state"><span>♜</span><strong>아직 완료한 대국이 없습니다</strong><p>빠른 대전이나 친구 초대로 첫 경기를 시작해 보세요.</p></div>';
      return;
    }

    for (const game of state.recentGames) {
      const row = document.createElement('div');
      row.className = 'recent-row';

      const mark = document.createElement('span');
      mark.className = `outcome-mark outcome-${game.outcome}`;
      mark.textContent = game.outcome === 'win' ? 'W' : game.outcome === 'loss' ? 'L' : 'D';

      const copy = document.createElement('div');
      copy.className = 'recent-copy';
      const opponent = document.createElement('strong');
      opponent.textContent = `vs ${game.opponent}`;
      const meta = document.createElement('small');
      meta.textContent = `${game.color === 'white' ? '백' : '흑'} · ${REASON_LABELS[game.reason] || '대국 종료'} · ${formatDate(game.finishedAt)}`;
      copy.append(opponent, meta);

      const result = document.createElement('span');
      result.className = 'recent-result';
      result.textContent = game.result || '—';

      const delta = document.createElement('span');
      const amount = Number(game.ratingDelta || 0);
      delta.className = `rating-delta ${amount > 0 ? 'positive' : amount < 0 ? 'negative' : 'neutral'}`;
      delta.textContent = game.rated ? `${amount > 0 ? '+' : ''}${amount}` : 'UNRATED';

      row.append(mark, copy, result, delta);
      elements.recentGamesList.appendChild(row);
    }
  }

  function showLobby() {
    elements.loadingView.hidden = true;
    elements.gameView.hidden = true;
    elements.lobbyView.hidden = false;
    stopClockTicker();
  }

  function showGame() {
    elements.loadingView.hidden = true;
    elements.lobbyView.hidden = true;
    elements.gameView.hidden = false;
  }

  function handleGameState(game) {
    if (!game) return;
    state.game = game;
    state.finishedGame = null;
    state.selectedSquare = null;
    state.moving = false;
    stopQueueOverlay();
    state.inviteCode = null;
    closeModal(true);
    renderGame();
  }

  async function handleGameFinished(finished) {
    if (!finished || !state.me) return;
    stopQueueOverlay();
    state.finishedGame = finished;
    state.selectedSquare = null;
    state.moving = false;

    const previous = state.game || {};
    state.game = {
      ...previous,
      ...finished,
      color: finished.white.id === state.me.id ? 'white' : 'black',
      turn: previous.turn || 'white',
      legalMoves: [],
      clocks: previous.clocks || { whiteMs: 0, blackMs: 0, serverNow: Date.now(), incrementMs: 0 },
      status: 'finished',
      drawOffer: null,
    };
    renderGame();
    stopClockTicker();
    await refreshDashboardData({ preserveGame: true });
    openResultModal(finished);
  }

  function renderGame() {
    if (!state.game) return;
    showGame();
    const game = state.game;
    const modeLabel = game.mode === 'invite' ? '친구 초대 대전' : '빠른 대전';
    elements.gameTitle.textContent = game.rated ? `${modeLabel} · 레이팅` : `${modeLabel} · 일반`;
    elements.gameRatedBadge.textContent = game.rated ? 'RATED' : 'UNRATED';
    elements.gameRatedBadge.classList.toggle('rated', game.rated);
    elements.gameIdLabel.textContent = `GAME ${String(game.id).slice(0, 8).toUpperCase()}`;
    elements.gameModeLabel.textContent = modeLabel;
    updateConnectionUi();
    renderPlayerPanels();
    renderBoard();
    renderMoves();
    renderGameStatus();
    if (game.status === 'active') startClockTicker();
    else stopClockTicker();
  }

  function myColor() {
    if (!state.game) return null;
    if (state.game.color) return state.game.color;
    if (state.game.white?.id === state.me?.id) return 'white';
    if (state.game.black?.id === state.me?.id) return 'black';
    return null;
  }

  function renderPlayerPanels() {
    const game = state.game;
    const color = myColor();
    const mine = color === 'white' ? game.white : game.black;
    const opponent = color === 'white' ? game.black : game.white;
    const mineColor = color;
    const opponentColor = color === 'white' ? 'black' : 'white';

    renderPlayerPanel(elements.myPanel, mine, mineColor, true);
    renderPlayerPanel(elements.opponentPanel, opponent, opponentColor, false);
    renderClockValues();
  }

  function renderPlayerPanel(container, player, color, isMe) {
    const activeTurn = state.game.status === 'active' && state.game.turn === color;
    container.classList.toggle('active-turn', activeTurn);
    const online = isMe ? state.connected : Boolean(player?.online);
    const piece = color === 'white' ? '♔' : '♚';
    const clockId = isMe ? 'myClock' : 'opponentClock';
    container.innerHTML = `
      <span class="player-piece-icon ${color === 'white' ? 'piece-white' : 'piece-black'}">${piece}</span>
      <div class="player-info">
        <strong>${escapeHtml(player?.handle || 'Player')}${isMe ? ' (나)' : ''}</strong>
        <small><span class="presence-label ${online ? '' : 'offline'}">${online ? '온라인' : '연결 끊김'}</span> · ${formatNumber(player?.rating ?? player?.ratingBefore ?? 100)} RP</small>
      </div>
      <span id="${clockId}" class="player-clock">00:00</span>
    `;
  }

  function currentClientClocks() {
    const game = state.game;
    const base = game?.clocks || { whiteMs: 0, blackMs: 0, serverNow: Date.now() };
    let whiteMs = Number(base.whiteMs || 0);
    let blackMs = Number(base.blackMs || 0);
    if (game?.status === 'active') {
      const elapsed = Math.max(0, Date.now() - Number(base.serverNow || Date.now()));
      if (game.turn === 'white') whiteMs = Math.max(0, whiteMs - elapsed);
      else blackMs = Math.max(0, blackMs - elapsed);
    }
    return { whiteMs, blackMs };
  }

  function renderClockValues() {
    if (!state.game) return;
    const clocks = currentClientClocks();
    const color = myColor();
    const myMs = color === 'white' ? clocks.whiteMs : clocks.blackMs;
    const opponentMs = color === 'white' ? clocks.blackMs : clocks.whiteMs;
    const mine = $('myClock');
    const opponent = $('opponentClock');
    if (mine) {
      mine.textContent = formatClock(myMs);
      mine.classList.toggle('low-time', state.game.status === 'active' && myMs <= 30_000);
    }
    if (opponent) {
      opponent.textContent = formatClock(opponentMs);
      opponent.classList.toggle('low-time', state.game.status === 'active' && opponentMs <= 30_000);
    }
  }

  function startClockTicker() {
    if (state.clockTimer) return;
    state.clockTimer = window.setInterval(renderClockValues, 200);
  }

  function stopClockTicker() {
    if (!state.clockTimer) return;
    window.clearInterval(state.clockTimer);
    state.clockTimer = null;
  }

  function parseFen(fen) {
    const map = new Map();
    const ranks = String(fen || '').split(' ')[0]?.split('/') || [];
    for (let row = 0; row < ranks.length; row += 1) {
      let fileIndex = 0;
      for (const token of ranks[row]) {
        if (/\d/.test(token)) {
          fileIndex += Number(token);
        } else {
          const square = `${String.fromCharCode(97 + fileIndex)}${8 - row}`;
          map.set(square, token);
          fileIndex += 1;
        }
      }
    }
    return map;
  }

  function renderBoard() {
    const game = state.game;
    const position = parseFen(game.fen);
    const color = myColor() || 'white';
    const files = color === 'black' ? ['h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'] : ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
    const ranks = color === 'black' ? [1, 2, 3, 4, 5, 6, 7, 8] : [8, 7, 6, 5, 4, 3, 2, 1];
    const legalMoves = game.legalMoves || [];
    const legalFrom = new Set(legalMoves.map((move) => move.from));
    const targets = state.selectedSquare
      ? legalMoves.filter((move) => move.from === state.selectedSquare)
      : [];
    const targetSquares = new Set(targets.map((move) => move.to));
    const lastMove = game.lastMove || null;

    elements.chessBoard.textContent = '';
    ranks.forEach((rank, rowIndex) => {
      files.forEach((file, columnIndex) => {
        const squareName = `${file}${rank}`;
        const fileIndex = file.charCodeAt(0) - 97;
        const isLight = (fileIndex + rank) % 2 === 0;
        const pieceCode = position.get(squareName);
        const square = document.createElement('button');
        square.type = 'button';
        square.className = `square ${isLight ? 'light' : 'dark'}`;
        square.dataset.square = squareName;
        square.setAttribute('role', 'gridcell');
        square.setAttribute('aria-label', `${squareName}${pieceCode ? ` ${pieceCode}` : ''}`);

        if (lastMove && (lastMove.from === squareName || lastMove.to === squareName)) square.classList.add('last-move');
        if (state.selectedSquare === squareName) square.classList.add('selected');
        if (game.checkSquare === squareName) square.classList.add('check-square');
        if (legalFrom.has(squareName)) square.classList.add('selectable');
        if (targetSquares.has(squareName)) {
          square.classList.add('legal-target');
          if (pieceCode) square.classList.add('legal-capture');
        }

        if (pieceCode) {
          const piece = document.createElement('span');
          piece.className = `piece ${pieceCode === pieceCode.toUpperCase() ? 'piece-white' : 'piece-black'}`;
          piece.textContent = PIECES[pieceCode];
          square.appendChild(piece);
        }

        if (rowIndex === 7) {
          const coordinate = document.createElement('span');
          coordinate.className = 'coord coord-file';
          coordinate.textContent = file;
          square.appendChild(coordinate);
        }
        if (columnIndex === 0) {
          const coordinate = document.createElement('span');
          coordinate.className = 'coord coord-rank';
          coordinate.textContent = String(rank);
          square.appendChild(coordinate);
        }

        square.addEventListener('click', () => handleSquareClick(squareName));
        elements.chessBoard.appendChild(square);
      });
    });
  }

  function handleSquareClick(square) {
    const game = state.game;
    if (!game || game.status !== 'active' || state.moving) return;
    const moves = game.legalMoves || [];
    const selectableMoves = moves.filter((move) => move.from === square);

    if (!state.selectedSquare) {
      if (selectableMoves.length) {
        state.selectedSquare = square;
        renderBoard();
      }
      return;
    }

    const targetMoves = moves.filter((move) => move.from === state.selectedSquare && move.to === square);
    if (targetMoves.length) {
      if (targetMoves.some((move) => move.promotion)) {
        openPromotion(targetMoves);
      } else {
        sendMove(state.selectedSquare, square);
      }
      return;
    }

    if (selectableMoves.length) state.selectedSquare = square;
    else state.selectedSquare = null;
    renderBoard();
  }

  function openPromotion(moves) {
    state.pendingPromotion = moves;
    elements.promotionChoices.textContent = '';
    const color = myColor() || 'white';
    const seen = new Set();
    for (const move of moves) {
      if (!move.promotion || seen.has(move.promotion)) continue;
      seen.add(move.promotion);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `promotion-choice ${color === 'white' ? 'piece-white' : 'piece-black'}`;
      button.textContent = PROMOTION_PIECES[color][move.promotion];
      button.setAttribute('aria-label', `${move.promotion}로 승격`);
      button.addEventListener('click', () => {
        elements.promotionOverlay.hidden = true;
        const selected = state.pendingPromotion?.find((item) => item.promotion === move.promotion);
        state.pendingPromotion = null;
        if (selected) sendMove(selected.from, selected.to, selected.promotion);
      });
      elements.promotionChoices.appendChild(button);
    }
    elements.promotionOverlay.hidden = false;
  }

  async function sendMove(from, to, promotion) {
    if (!state.game) return;
    const gameId = state.game.id;
    state.selectedSquare = null;
    state.moving = true;
    renderBoard();
    try {
      await emitAck('game:move', { gameId, from, to, promotion });
    } catch (error) {
      state.moving = false;
      showToast(error.message, 'error');
      try {
        const response = await emitAck('game:sync', { gameId });
        handleGameState(response.game);
      } catch {
        // Reconnection handler will retry.
      }
    }
  }

  function renderMoves() {
    const history = state.game?.history || [];
    elements.moveCount.textContent = `${history.length}수`;
    elements.moveList.textContent = '';
    if (!history.length) {
      elements.moveList.innerHTML = '<div class="no-moves">첫 수를 기다리고 있습니다.<br>중앙을 장악해 보세요.</div>';
      return;
    }

    for (let index = 0; index < history.length; index += 2) {
      const row = document.createElement('div');
      row.className = 'move-row';
      const number = document.createElement('span');
      number.className = 'move-number';
      number.textContent = `${Math.floor(index / 2) + 1}.`;
      const white = document.createElement('span');
      white.className = `move-san${index === history.length - 1 ? ' latest' : ''}`;
      white.textContent = history[index] || '';
      const black = document.createElement('span');
      black.className = `move-san${index + 1 === history.length - 1 ? ' latest' : ''}`;
      black.textContent = history[index + 1] || '';
      row.append(number, white, black);
      elements.moveList.appendChild(row);
    }
    elements.moveList.scrollTop = elements.moveList.scrollHeight;
  }

  function renderGameStatus() {
    const game = state.game;
    if (!game) return;
    const color = myColor();
    const myTurn = game.turn === color;
    const opponent = color === 'white' ? game.black : game.white;

    if (game.status === 'finished') {
      elements.turnStatus.textContent = '대국이 종료되었습니다';
      elements.turnDetail.textContent = REASON_LABELS[game.reason] || '결과를 확인해 주세요.';
    } else if (game.inCheck && myTurn) {
      elements.turnStatus.textContent = '체크! 내 차례입니다';
      elements.turnDetail.textContent = '킹을 안전한 칸으로 피하거나 공격을 막아야 합니다.';
    } else if (myTurn) {
      elements.turnStatus.textContent = '내 차례입니다';
      elements.turnDetail.textContent = `${color === 'white' ? '백' : '흑'}으로 둘 수를 선택하세요.`;
    } else {
      elements.turnStatus.textContent = '상대의 차례입니다';
      elements.turnDetail.textContent = opponent?.online === false
        ? '상대 연결이 끊겼지만 시계는 계속 흐릅니다.'
        : `${opponent?.handle || '상대'}의 수를 기다리고 있습니다.`;
    }

    const active = game.status === 'active';
    elements.offerDrawButton.disabled = !active || game.drawOffer === 'sent';
    elements.offerDrawButton.innerHTML = game.drawOffer === 'sent'
      ? '<span>½</span> 제안 전송됨'
      : '<span>½</span> 무승부 제안';
    elements.resignButton.disabled = !active;
    elements.drawOfferBox.hidden = !(active && game.drawOffer === 'received');
  }

  function startQueueOverlay() {
    state.queueing = true;
    state.queueStartedAt = Date.now();
    elements.queueOverlay.hidden = false;
    document.body.classList.add('modal-open');
    if (state.queueTimer) window.clearInterval(state.queueTimer);
    state.queueTimer = window.setInterval(() => {
      const elapsed = Math.floor((Date.now() - state.queueStartedAt) / 1000);
      elements.queueTime.textContent = `${String(Math.floor(elapsed / 60)).padStart(2, '0')}:${String(elapsed % 60).padStart(2, '0')}`;
    }, 250);
  }

  function stopQueueOverlay() {
    state.queueing = false;
    elements.queueOverlay.hidden = true;
    if (state.queueTimer) window.clearInterval(state.queueTimer);
    state.queueTimer = null;
    elements.queueTime.textContent = '00:00';
    if (elements.modalRoot.hidden && elements.promotionOverlay.hidden) document.body.classList.remove('modal-open');
  }

  async function quickMatch() {
    if (state.game?.status === 'active') {
      showToast('이미 진행 중인 대국이 있습니다.', 'info');
      return;
    }
    try {
      const response = await emitAck('match:queue');
      if (response.activeGame) {
        handleGameState(response.activeGame);
        return;
      }
      if (response.queued) startQueueOverlay();
    } catch (error) {
      showToast(error.message, 'error');
    }
  }

  async function cancelQueue() {
    try {
      await emitAck('match:cancel');
    } catch {
      // Local overlay should still close.
    }
    stopQueueOverlay();
  }

  function openModal(content, { onClose = null, locked = false } = {}) {
    elements.modalContent.innerHTML = content;
    state.modalOnClose = onClose;
    state.modalLocked = locked;
    elements.modalCloseButton.hidden = locked;
    elements.modalRoot.hidden = false;
    document.body.classList.add('modal-open');
  }

  function closeModal(force = false) {
    if (elements.modalRoot.hidden) return;
    if (state.modalLocked && !force) return;
    const onClose = state.modalOnClose;
    state.modalOnClose = null;
    state.modalLocked = false;
    elements.modalRoot.hidden = true;
    elements.modalContent.textContent = '';
    elements.modalCloseButton.hidden = false;
    if (!force && typeof onClose === 'function') onClose();
    if (elements.queueOverlay.hidden && elements.promotionOverlay.hidden) document.body.classList.remove('modal-open');
  }

  function accountLinkForm() {
    return `
      <form id="linkAccountForm" class="form-stack">
        <label class="field-label">아이디<input name="handle" autocomplete="username" minlength="3" maxlength="20" placeholder="예: chess_master" required></label>
        <label class="field-label">이메일<input name="email" type="email" autocomplete="email" maxlength="120" placeholder="name@example.com" required></label>
        <label class="field-label">비밀번호<input name="password" type="password" autocomplete="new-password" minlength="8" maxlength="128" placeholder="8자 이상" required></label>
        <button class="submit-button" type="submit">레이팅과 전적을 계정에 연결</button>
        <p class="form-note">현재 ${formatNumber(state.me?.rating)} RP와 모든 대국 기록이 그대로 유지됩니다.</p>
      </form>
    `;
  }

  function loginForm() {
    return `
      <form id="loginForm" class="form-stack">
        <label class="field-label">아이디 또는 이메일<input name="identity" autocomplete="username" maxlength="120" placeholder="아이디 또는 이메일" required></label>
        <label class="field-label">비밀번호<input name="password" type="password" autocomplete="current-password" minlength="8" maxlength="128" placeholder="비밀번호" required></label>
        <button class="submit-button" type="submit">기존 계정으로 로그인</button>
        <p class="form-note">로그인하면 현재 게스트 세션 대신 기존 계정이 열립니다.</p>
      </form>
    `;
  }

  function openAccountModal(defaultTab = 'link') {
    if (!state.me) return;
    if (!state.me.isGuest) {
      openModal(`
        <div class="modal-body">
          <span class="section-kicker">ACCOUNT</span>
          <h2>계정 정보</h2>
          <p class="modal-description">레이팅과 대국 기록이 이 계정에 안전하게 저장되고 있습니다.</p>
          <div class="account-summary">
            <span class="avatar avatar-large">${escapeHtml(initial(state.me.handle))}</span>
            <div class="account-summary-copy"><strong>${escapeHtml(state.me.handle)}</strong><span>${formatNumber(state.me.rating)} RP · ${state.me.gamesPlayed}경기</span></div>
          </div>
          <button id="logoutButton" class="danger-button" type="button">로그아웃</button>
        </div>
      `);
      $('logoutButton').addEventListener('click', async () => {
        try {
          await api('/api/auth/logout', { method: 'POST' });
          window.location.reload();
        } catch (error) {
          showToast(error.message, 'error');
        }
      });
      return;
    }

    const renderTab = (tab) => {
      elements.modalContent.innerHTML = `
        <div class="modal-body">
          <span class="section-kicker">SAVE YOUR PROGRESS</span>
          <h2>게스트 기록 보존하기</h2>
          <p class="modal-description">현재 레이팅과 전적을 새 계정에 연결하거나 기존 계정으로 로그인하세요.</p>
          <div class="tabs">
            <button id="linkTabButton" class="tab-button ${tab === 'link' ? 'active' : ''}" type="button">새 계정 연결</button>
            <button id="loginTabButton" class="tab-button ${tab === 'login' ? 'active' : ''}" type="button">기존 계정 로그인</button>
          </div>
          ${tab === 'link' ? accountLinkForm() : loginForm()}
        </div>
      `;
      $('linkTabButton').addEventListener('click', () => renderTab('link'));
      $('loginTabButton').addEventListener('click', () => renderTab('login'));
      if (tab === 'link') bindLinkForm();
      else bindLoginForm();
    };

    openModal('<div></div>');
    renderTab(defaultTab);
  }

  function bindLinkForm() {
    const form = $('linkAccountForm');
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = form.querySelector('button[type="submit"]');
      const formData = new FormData(form);
      button.disabled = true;
      button.textContent = '연결하는 중…';
      try {
        await api('/api/auth/link', {
          method: 'POST',
          body: {
            handle: formData.get('handle'),
            email: formData.get('email'),
            password: formData.get('password'),
          },
        });
        showToast('계정 연결이 완료되었습니다.');
        window.setTimeout(() => window.location.reload(), 350);
      } catch (error) {
        button.disabled = false;
        button.textContent = '레이팅과 전적을 계정에 연결';
        showToast(error.message, 'error');
      }
    });
  }

  function bindLoginForm() {
    const form = $('loginForm');
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = form.querySelector('button[type="submit"]');
      const formData = new FormData(form);
      button.disabled = true;
      button.textContent = '로그인 중…';
      try {
        await api('/api/auth/login', {
          method: 'POST',
          body: {
            identity: formData.get('identity'),
            password: formData.get('password'),
          },
        });
        showToast('로그인되었습니다.');
        window.setTimeout(() => window.location.reload(), 350);
      } catch (error) {
        button.disabled = false;
        button.textContent = '기존 계정으로 로그인';
        showToast(error.message, 'error');
      }
    });
  }

  function openInviteModal() {
    openModal(`
      <div class="modal-body">
        <span class="section-kicker">PLAY WITH A FRIEND</span>
        <h2>친구와 온라인 대전</h2>
        <p class="modal-description">초대 코드를 만들거나 친구에게 받은 6자리 코드를 입력하세요.</p>
        <div class="invite-options">
          <div class="invite-option-card">
            <h3>새 초대 만들기</h3>
            <p>코드를 공유하면 친구가 같은 VPS 서버에서 바로 입장할 수 있습니다.</p>
            <div class="toggle-row"><span>레이팅 반영</span><label class="toggle"><input id="inviteRatedToggle" type="checkbox" checked><span></span></label></div>
            <button id="createInviteButton" class="submit-button full-submit" type="button">초대 코드 만들기</button>
          </div>
          <div class="invite-option-card">
            <h3>초대 코드로 참가</h3>
            <p>친구에게 받은 코드를 입력하면 즉시 대국이 시작됩니다.</p>
            <form id="joinInviteForm" class="form-stack no-top-margin">
              <input id="inviteCodeInput" class="code-input" name="code" maxlength="6" autocomplete="off" placeholder="예: A7K9PX" required>
              <button class="submit-button" type="submit">대국 참가</button>
            </form>
          </div>
        </div>
      </div>
    `);

    $('createInviteButton').addEventListener('click', async () => {
      const button = $('createInviteButton');
      button.disabled = true;
      button.textContent = '코드 생성 중…';
      try {
        const response = await emitAck('invite:create', { rated: $('inviteRatedToggle').checked });
        showInviteCode(response);
      } catch (error) {
        button.disabled = false;
        button.textContent = '초대 코드 만들기';
        showToast(error.message, 'error');
      }
    });

    $('inviteCodeInput').addEventListener('input', (event) => {
      event.target.value = event.target.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase().slice(0, 6);
    });

    $('joinInviteForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const button = form.querySelector('button');
      const code = $('inviteCodeInput').value.trim().toUpperCase();
      button.disabled = true;
      button.textContent = '입장 중…';
      try {
        await emitAck('invite:join', { code });
      } catch (error) {
        button.disabled = false;
        button.textContent = '대국 참가';
        showToast(error.message, 'error');
      }
    });
  }

  function showInviteCode(invite) {
    state.inviteCode = invite.code;
    state.modalOnClose = () => {
      emitAck('invite:cancel').catch(() => {});
      state.inviteCode = null;
    };
    elements.modalContent.innerHTML = `
      <div class="modal-body">
        <span class="section-kicker">INVITE READY</span>
        <h2>친구를 기다리고 있습니다</h2>
        <p class="modal-description">아래 코드를 친구에게 보내세요. 친구가 입력하면 자동으로 대국 화면으로 이동합니다.</p>
        <div class="invite-code-display"><small>INVITE CODE · ${invite.rated ? 'RATED' : 'UNRATED'}</small><strong>${escapeHtml(invite.code)}</strong></div>
        <button id="copyInviteButton" class="copy-button" type="button">초대 코드 복사</button>
        <p class="waiting-note"><i class="live-dot"></i> 상대 접속 대기 중</p>
      </div>
    `;
    $('copyInviteButton').addEventListener('click', () => copyText(invite.code));
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      showToast('초대 코드를 복사했습니다.');
    } catch {
      const input = document.createElement('textarea');
      input.value = text;
      input.className = 'clipboard-helper';
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      input.remove();
      showToast('초대 코드를 복사했습니다.');
    }
  }

  function openConfirm({ title, description, confirmLabel, danger = false, onConfirm }) {
    openModal(`
      <div class="modal-body">
        <span class="section-kicker">CONFIRM</span>
        <h2>${escapeHtml(title)}</h2>
        <p class="modal-description">${escapeHtml(description)}</p>
        <div class="confirm-actions">
          <button id="confirmCancelButton" class="confirm-cancel" type="button">취소</button>
          <button id="confirmActionButton" class="${danger ? 'confirm-danger' : 'submit-button'}" type="button">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>
    `);
    $('confirmCancelButton').addEventListener('click', () => closeModal());
    $('confirmActionButton').addEventListener('click', async () => {
      const button = $('confirmActionButton');
      button.disabled = true;
      try {
        await onConfirm();
        closeModal(true);
      } catch (error) {
        button.disabled = false;
        showToast(error.message, 'error');
      }
    });
  }

  function openResultModal(finished) {
    const isDraw = finished.winnerUserId === null;
    const isWin = finished.winnerUserId === state.me.id;
    const mine = finished.white.id === state.me.id ? finished.white : finished.black;
    const title = isDraw ? '무승부입니다' : isWin ? '승리했습니다' : '패배했습니다';
    const icon = isDraw ? '♜' : isWin ? '♛' : '♟';
    const delta = Number(mine.ratingDelta || 0);
    const deltaClass = delta > 0 ? '' : delta < 0 ? 'negative' : 'neutral';
    const reason = REASON_LABELS[finished.reason] || '대국 종료';

    const leaveResult = () => {
      state.game = null;
      state.finishedGame = null;
      state.selectedSquare = null;
      renderAll();
    };

    openModal(`
      <div class="result-hero">
        <div class="result-icon">${icon}</div>
        <h2>${title}</h2>
        <p>${escapeHtml(reason)} · ${escapeHtml(finished.result || '')}</p>
        <div class="result-rating"><strong>${formatNumber(mine.ratingAfter)}</strong><span class="${deltaClass}">${finished.rated ? `${delta > 0 ? '+' : ''}${delta} RP` : 'UNRATED'}</span></div>
        <p>${finished.rated ? '새 레이팅이 프로필과 순위표에 반영되었습니다.' : '일반 대전은 레이팅에 반영되지 않습니다.'}</p>
        <div class="result-actions">
          <button id="resultHomeButton" class="result-home" type="button">로비로</button>
          <button id="resultNextButton" class="result-rematch" type="button">다음 상대 찾기</button>
        </div>
      </div>
    `, { onClose: leaveResult });

    $('resultHomeButton').addEventListener('click', () => {
      closeModal(true);
      leaveResult();
    });
    $('resultNextButton').addEventListener('click', () => {
      closeModal(true);
      leaveResult();
      quickMatch();
    });
  }

  async function refreshLeaderboard() {
    elements.refreshLeaderboardButton.disabled = true;
    try {
      const data = await api('/api/leaderboard');
      state.leaderboard = data.leaderboard || [];
      renderLeaderboard();
    } catch (error) {
      showToast(error.message, 'error');
    } finally {
      elements.refreshLeaderboardButton.disabled = false;
    }
  }

  elements.quickMatchButton.addEventListener('click', quickMatch);
  elements.cancelQueueButton.addEventListener('click', cancelQueue);
  elements.openInviteButton.addEventListener('click', openInviteModal);
  elements.accountButton.addEventListener('click', () => openAccountModal(state.me?.isGuest ? 'link' : 'account'));
  elements.profileAccountAction.addEventListener('click', () => openAccountModal('link'));
  elements.refreshLeaderboardButton.addEventListener('click', refreshLeaderboard);
  elements.modalCloseButton.addEventListener('click', () => closeModal());
  elements.modalBackdrop.addEventListener('click', () => closeModal());

  elements.brandButton.addEventListener('click', () => {
    if (state.game?.status === 'active') {
      showToast('대국이 끝난 뒤 로비로 이동할 수 있습니다.', 'info');
      return;
    }
    state.game = null;
    renderAll();
  });

  elements.offerDrawButton.addEventListener('click', async () => {
    if (!state.game) return;
    try {
      await emitAck('game:draw-offer', { gameId: state.game.id });
      showToast(state.game.drawOffer === 'received' ? '무승부 제안을 수락했습니다.' : '무승부를 제안했습니다.', 'info');
    } catch (error) {
      showToast(error.message, 'error');
    }
  });

  elements.acceptDrawButton.addEventListener('click', async () => {
    if (!state.game) return;
    try {
      await emitAck('game:draw-offer', { gameId: state.game.id });
    } catch (error) {
      showToast(error.message, 'error');
    }
  });

  elements.declineDrawButton.addEventListener('click', async () => {
    if (!state.game) return;
    try {
      await emitAck('game:draw-decline', { gameId: state.game.id });
      showToast('무승부 제안을 거절했습니다.', 'info');
    } catch (error) {
      showToast(error.message, 'error');
    }
  });

  elements.resignButton.addEventListener('click', () => {
    if (!state.game) return;
    openConfirm({
      title: '정말 기권할까요?',
      description: state.game.rated ? '기권하면 패배로 기록되고 레이팅이 반영됩니다.' : '기권하면 패배로 기록됩니다.',
      confirmLabel: '기권하기',
      danger: true,
      onConfirm: () => emitAck('game:resign', { gameId: state.game.id }),
    });
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    if (!elements.promotionOverlay.hidden) return;
    if (!elements.queueOverlay.hidden) {
      cancelQueue();
      return;
    }
    closeModal();
  });

  window.addEventListener('beforeunload', () => {
    if (state.inviteCode) state.socket?.emit('invite:cancel');
  });

  elements.currentYear.textContent = String(new Date().getFullYear());
  loadBootstrap();
})();
