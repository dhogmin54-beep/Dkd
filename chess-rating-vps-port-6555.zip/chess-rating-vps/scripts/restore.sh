#!/usr/bin/env bash
set -Eeuo pipefail

if [[ $# -ne 1 ]]; then
  echo "사용법: $0 /path/to/nova-chess-YYYYMMDD-HHMMSS.tar.gz" >&2
  exit 1
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ ! -f "$1" ]]; then
  echo "백업 파일을 찾을 수 없습니다: $1" >&2
  exit 1
fi

ARCHIVE_PATH="$(realpath "$1")"
ARCHIVE_DIR="$(dirname "$ARCHIVE_PATH")"
ARCHIVE_NAME="$(basename "$ARCHIVE_PATH")"
VOLUME_NAME="${VOLUME_NAME:-nova_chess_data}"

if ! docker run --rm \
  -v "$ARCHIVE_DIR:/backup:ro" \
  alpine:3.22 \
  sh -c 'tar -tzf "/backup/$1" >/dev/null' \
  _ "$ARCHIVE_NAME"; then
  echo "올바른 gzip tar 백업 파일이 아닙니다: $ARCHIVE_PATH" >&2
  exit 1
fi

read -r -p "현재 데이터가 모두 교체됩니다. 복원할까요? [y/N] " ANSWER
if [[ ! "$ANSWER" =~ ^[Yy]$ ]]; then
  echo "취소했습니다."
  exit 0
fi

cd "$ROOT_DIR"
WAS_RUNNING=0
CONTAINER_ID="$(docker compose ps -q app 2>/dev/null || true)"
if [[ -n "$CONTAINER_ID" ]] && [[ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER_ID" 2>/dev/null || true)" == "true" ]]; then
  WAS_RUNNING=1
  docker compose stop app >/dev/null
fi

restart_app() {
  if [[ "$WAS_RUNNING" == "1" ]]; then
    docker compose start app >/dev/null
  fi
}
trap restart_app EXIT

docker run --rm \
  -v "$VOLUME_NAME:/data" \
  -v "$ARCHIVE_DIR:/backup:ro" \
  alpine:3.22 \
  sh -c 'find /data -mindepth 1 -maxdepth 1 -exec rm -rf {} + && tar -xzf "/backup/$1" -C /data' \
  _ "$ARCHIVE_NAME"

echo "복원 완료: $ARCHIVE_PATH"
