const crypto = require('node:crypto');
const { Chess } = require('chess.js');
const { calculateElo } = require('./rating');
const { now, randomId, cleanText } = require('./utils');

const INVITE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

class GameError extends Error {
  constructor(message, code = 'GAME_ERROR') {
    super(message);
    this.name = 'GameError';
    this.code = code;
  }
}

function createGameManager({ io, db, config }) {
  const activeGames = new Map();
  const queue = new Map();
  const invites = new Map();
  const userSockets = new Map();
  const initialClockMs = config.gameMinutes * 60 * 1000;
  const incrementMs = config.gameIncrementSeconds * 1000;

  function safeAck(ack, payload) {
    if (typeof ack === 'function') ack(payload);
  }

  function roomForGame(id) {
    return `game:${id}`;
  }

  function roomForUser(id) {
    return `user:${id}`;
  }

  function isOnline(userId) {
    return (userSockets.get(userId)?.size || 0) > 0;
  }

  function participantColor(game, userId) {
    if (game.whiteUserId === userId) return 'w';
    if (game.blackUserId === userId) return 'b';
    return null;
  }

  function opponentId(game, userId) {
    if (game.whiteUserId === userId) return game.blackUserId;
    if (game.blackUserId === userId) return game.whiteUserId;
    return null;
  }

  function ratedEligible(user) {
    return Boolean(user && !user.is_guest && user.password_hash);
  }

  function requireRatedEligibility(user) {
    if (!ratedEligible(user)) {
      throw new GameError('레이팅 대국은 회원가입 또는 로그인 후 이용할 수 있습니다.', 'ACCOUNT_REQUIRED');
    }
  }

  function addSocket(socket) {
    const userId = socket.user.id;
    if (!userSockets.has(userId)) userSockets.set(userId, new Set());
    userSockets.get(userId).add(socket.id);
    socket.join(roomForUser(userId));
  }

  function removeSocket(socket) {
    const userId = socket.user.id;
    const sockets = userSockets.get(userId);
    if (!sockets) return;
    sockets.delete(socket.id);
    if (sockets.size === 0) {
      userSockets.delete(userId);
      queue.delete(userId);
      for (const [code, invite] of invites) {
        if (invite.hostId === userId) invites.delete(code);
      }
    }
  }

  function joinUserSocketsToGame(userId, gameId) {
    const ids = userSockets.get(userId);
    if (!ids) return;
    for (const socketId of ids) {
      io.sockets.sockets.get(socketId)?.join(roomForGame(gameId));
    }
  }

  function currentClocks(game, at = now()) {
    let whiteMs = game.whiteClockMs;
    let blackMs = game.blackClockMs;
    const elapsed = Math.max(0, at - game.lastClockAt);
    if (game.chess.turn() === 'w') whiteMs = Math.max(0, whiteMs - elapsed);
    else blackMs = Math.max(0, blackMs - elapsed);
    return { whiteMs, blackMs };
  }

  function applyClock(game, at = now()) {
    const clocks = currentClocks(game, at);
    game.whiteClockMs = clocks.whiteMs;
    game.blackClockMs = clocks.blackMs;
    game.lastClockAt = at;
    return clocks;
  }

  function lastMove(game) {
    const move = game.chess.history({ verbose: true }).at(-1);
    if (!move) return null;
    return {
      from: move.from,
      to: move.to,
      san: move.san,
      color: move.color === 'w' ? 'white' : 'black',
      piece: move.piece,
      captured: move.captured || null,
      promotion: move.promotion || null,
    };
  }

  function checkSquare(game) {
    if (!game.chess.inCheck()) return null;
    const turn = game.chess.turn();
    for (const rank of game.chess.board()) {
      for (const piece of rank) {
        if (piece?.type === 'k' && piece.color === turn) return piece.square;
      }
    }
    return null;
  }

  function legalMovesFor(game, userId) {
    const color = participantColor(game, userId);
    if (!color || color !== game.chess.turn()) return [];
    return game.chess.moves({ verbose: true }).map((move) => ({
      from: move.from,
      to: move.to,
      promotion: move.promotion || null,
      san: move.san,
    }));
  }

  function publicPlayer(row, fallbackRating) {
    return {
      id: row.id,
      handle: row.handle,
      rating: fallbackRating ?? row.rating,
      isGuest: Boolean(row.is_guest),
      isAccount: !row.is_guest && Boolean(row.password_hash),
      ratedEligible: !row.is_guest && Boolean(row.password_hash),
      online: isOnline(row.id),
    };
  }

  function serializeActive(game, userId) {
    const white = db.getUserById(game.whiteUserId);
    const black = db.getUserById(game.blackUserId);
    const clocks = currentClocks(game);
    const color = participantColor(game, userId);

    return {
      id: game.id,
      status: 'active',
      mode: game.mode,
      rated: game.rated,
      color: color === 'w' ? 'white' : color === 'b' ? 'black' : null,
      fen: game.chess.fen(),
      pgn: game.chess.pgn(),
      turn: game.chess.turn() === 'w' ? 'white' : 'black',
      white: publicPlayer(white, game.whiteRatingBefore),
      black: publicPlayer(black, game.blackRatingBefore),
      clocks: {
        whiteMs: clocks.whiteMs,
        blackMs: clocks.blackMs,
        incrementMs,
        serverNow: now(),
      },
      history: game.chess.history(),
      lastMove: lastMove(game),
      legalMoves: legalMovesFor(game, userId),
      inCheck: game.chess.inCheck(),
      checkSquare: checkSquare(game),
      drawOffer: game.drawOfferedBy === null
        ? null
        : game.drawOfferedBy === userId ? 'sent' : 'received',
      createdAt: game.createdAt,
    };
  }

  function serializeFinished(game, finish) {
    const white = db.getUserById(game.whiteUserId);
    const black = db.getUserById(game.blackUserId);
    return {
      id: game.id,
      status: 'finished',
      mode: game.mode,
      rated: game.rated,
      fen: game.chess.fen(),
      pgn: game.chess.pgn(),
      history: game.chess.history(),
      lastMove: lastMove(game),
      result: finish.result,
      reason: finish.reason,
      winnerUserId: finish.winnerUserId,
      white: {
        ...publicPlayer(white, finish.whiteRatingAfter),
        ratingBefore: finish.whiteRatingBefore,
        ratingAfter: finish.whiteRatingAfter,
        ratingDelta: finish.whiteRatingDelta,
      },
      black: {
        ...publicPlayer(black, finish.blackRatingAfter),
        ratingBefore: finish.blackRatingBefore,
        ratingAfter: finish.blackRatingAfter,
        ratingDelta: finish.blackRatingDelta,
      },
      finishedAt: finish.finishedAt,
    };
  }

  function emitLobbyStats() {
    io.emit('lobby:stats', {
      online: userSockets.size,
      searching: queue.size,
      activeGames: activeGames.size,
    });
  }

  function emitActive(game, eventName = 'game:state') {
    io.to(roomForUser(game.whiteUserId)).emit(eventName, serializeActive(game, game.whiteUserId));
    io.to(roomForUser(game.blackUserId)).emit(eventName, serializeActive(game, game.blackUserId));
  }

  function persistGame(game) {
    db.updateGame({
      id: game.id,
      fen: game.chess.fen(),
      pgn: game.chess.pgn(),
      turn: game.chess.turn(),
      whiteClockMs: Math.round(game.whiteClockMs),
      blackClockMs: Math.round(game.blackClockMs),
      lastClockAt: game.lastClockAt,
    });
  }

  function makeGameFromRow(row) {
    const chess = new Chess();
    try {
      if (row.pgn) chess.loadPgn(row.pgn);
      else chess.load(row.fen);
    } catch (error) {
      throw new Error(`Could not restore game ${row.id}: ${error.message}`);
    }

    return {
      id: row.id,
      mode: row.mode,
      rated: Boolean(row.rated),
      whiteUserId: row.white_user_id,
      blackUserId: row.black_user_id,
      whiteRatingBefore: row.white_rating_before,
      blackRatingBefore: row.black_rating_before,
      whiteClockMs: row.white_clock_ms,
      blackClockMs: row.black_clock_ms,
      lastClockAt: row.last_clock_at,
      createdAt: row.created_at,
      chess,
      drawOfferedBy: null,
      finishing: false,
    };
  }

  function restoreActiveGames() {
    for (const row of db.listActiveGames()) {
      try {
        activeGames.set(row.id, makeGameFromRow(row));
      } catch (error) {
        console.error(error.message);
        db.abortGame(row.id, 'restore_error');
      }
    }
  }

  function activeGameForUser(userId) {
    const row = db.activeGameForUser(userId);
    if (!row) return null;
    return activeGames.get(row.id) || null;
  }

  function getActiveStateForUser(userId) {
    const game = activeGameForUser(userId);
    return game ? serializeActive(game, userId) : null;
  }

  function randomInviteCode() {
    for (let attempt = 0; attempt < 50; attempt += 1) {
      let code = '';
      const bytes = crypto.randomBytes(6);
      for (let index = 0; index < 6; index += 1) {
        code += INVITE_ALPHABET[bytes[index] % INVITE_ALPHABET.length];
      }
      if (!invites.has(code)) return code;
    }
    throw new GameError('초대 코드를 만들지 못했습니다. 다시 시도해 주세요.', 'INVITE_CREATE_FAILED');
  }

  function clearUserLobbyState(userId) {
    queue.delete(userId);
    for (const [code, invite] of invites) {
      if (invite.hostId === userId) invites.delete(code);
    }
  }

  function createGame(userAId, userBId, { mode, rated }) {
    if (userAId === userBId) throw new GameError('같은 계정끼리는 대국할 수 없습니다.', 'SAME_USER');
    if (activeGameForUser(userAId) || activeGameForUser(userBId)) {
      throw new GameError('이미 진행 중인 대국이 있습니다.', 'ALREADY_IN_GAME');
    }

    const userA = db.getUserById(userAId);
    const userB = db.getUserById(userBId);
    if (!userA || !userB) throw new GameError('대국 상대를 찾을 수 없습니다.', 'USER_NOT_FOUND');
    if (rated) {
      requireRatedEligibility(userA);
      requireRatedEligibility(userB);
    }

    const aIsWhite = crypto.randomInt(0, 2) === 0;
    const white = aIsWhite ? userA : userB;
    const black = aIsWhite ? userB : userA;
    const chess = new Chess();
    const timestamp = now();
    const game = {
      id: randomId(12),
      mode,
      rated: Boolean(rated),
      whiteUserId: white.id,
      blackUserId: black.id,
      whiteRatingBefore: white.rating,
      blackRatingBefore: black.rating,
      whiteClockMs: initialClockMs,
      blackClockMs: initialClockMs,
      lastClockAt: timestamp,
      createdAt: timestamp,
      chess,
      drawOfferedBy: null,
      finishing: false,
    };

    db.createGame({
      id: game.id,
      mode,
      rated: rated ? 1 : 0,
      whiteUserId: game.whiteUserId,
      blackUserId: game.blackUserId,
      fen: chess.fen(),
      pgn: chess.pgn(),
      turn: chess.turn(),
      whiteClockMs: initialClockMs,
      blackClockMs: initialClockMs,
      lastClockAt: timestamp,
      whiteRatingBefore: white.rating,
      blackRatingBefore: black.rating,
      createdAt: timestamp,
    });

    activeGames.set(game.id, game);
    clearUserLobbyState(userAId);
    clearUserLobbyState(userBId);
    joinUserSocketsToGame(userAId, game.id);
    joinUserSocketsToGame(userBId, game.id);
    emitActive(game, 'game:started');
    emitLobbyStats();
    return game;
  }

  function finishGame(game, { winnerUserId = null, reason }) {
    if (!game || game.finishing || !activeGames.has(game.id)) return null;
    game.finishing = true;
    const timestamp = now();
    applyClock(game, timestamp);

    const whiteScore = winnerUserId === null ? 0.5 : winnerUserId === game.whiteUserId ? 1 : 0;
    let whiteRatingAfter = game.whiteRatingBefore;
    let blackRatingAfter = game.blackRatingBefore;
    let whiteRatingDelta = 0;
    let blackRatingDelta = 0;

    if (game.rated) {
      const rating = calculateElo(
        game.whiteRatingBefore,
        game.blackRatingBefore,
        whiteScore,
        { k: config.eloK, floor: config.ratingFloor },
      );
      whiteRatingAfter = rating.ratingA;
      blackRatingAfter = rating.ratingB;
      whiteRatingDelta = whiteRatingAfter - game.whiteRatingBefore;
      blackRatingDelta = blackRatingAfter - game.blackRatingBefore;
    }

    const result = winnerUserId === null
      ? '1/2-1/2'
      : winnerUserId === game.whiteUserId ? '1-0' : '0-1';

    const finish = {
      id: game.id,
      rated: game.rated,
      whiteUserId: game.whiteUserId,
      blackUserId: game.blackUserId,
      fen: game.chess.fen(),
      pgn: game.chess.pgn(),
      turn: game.chess.turn(),
      whiteClockMs: Math.round(game.whiteClockMs),
      blackClockMs: Math.round(game.blackClockMs),
      lastClockAt: game.lastClockAt,
      result,
      winnerUserId,
      reason,
      whiteRatingBefore: game.whiteRatingBefore,
      blackRatingBefore: game.blackRatingBefore,
      whiteRatingAfter,
      blackRatingAfter,
      whiteRatingDelta,
      blackRatingDelta,
      finishedAt: timestamp,
    };

    try {
      db.finishGame(finish);
      activeGames.delete(game.id);
      const payload = serializeFinished(game, finish);
      io.to(roomForGame(game.id)).emit('game:finished', payload);
      io.emit('leaderboard:changed');
      emitLobbyStats();
      return payload;
    } catch (error) {
      game.finishing = false;
      throw error;
    }
  }

  function gameOverReason(game) {
    if (game.chess.isCheckmate()) return 'checkmate';
    if (game.chess.isStalemate()) return 'stalemate';
    if (game.chess.isThreefoldRepetition()) return 'threefold_repetition';
    if (game.chess.isInsufficientMaterial()) return 'insufficient_material';
    if (typeof game.chess.isDrawByFiftyMoves === 'function' && game.chess.isDrawByFiftyMoves()) return 'fifty_move_rule';
    return 'draw';
  }

  function processMove(userId, payload) {
    const game = activeGames.get(cleanText(payload?.gameId, 64));
    if (!game) throw new GameError('진행 중인 대국을 찾을 수 없습니다.', 'GAME_NOT_FOUND');
    const color = participantColor(game, userId);
    if (!color) throw new GameError('이 대국에 참여한 계정이 아닙니다.', 'NOT_A_PLAYER');
    if (game.chess.turn() !== color) throw new GameError('현재 내 차례가 아닙니다.', 'NOT_YOUR_TURN');

    const timestamp = now();
    const clocks = applyClock(game, timestamp);
    if ((color === 'w' ? clocks.whiteMs : clocks.blackMs) <= 0) {
      const winner = opponentId(game, userId);
      finishGame(game, { winnerUserId: winner, reason: 'timeout' });
      throw new GameError('시간이 종료되었습니다.', 'TIMEOUT');
    }

    const from = cleanText(payload?.from, 2).toLowerCase();
    const to = cleanText(payload?.to, 2).toLowerCase();
    const promotion = cleanText(payload?.promotion, 1).toLowerCase() || undefined;
    if (!/^[a-h][1-8]$/.test(from) || !/^[a-h][1-8]$/.test(to)) {
      throw new GameError('잘못된 칸 정보입니다.', 'INVALID_SQUARE');
    }
    if (promotion && !['q', 'r', 'b', 'n'].includes(promotion)) {
      throw new GameError('잘못된 승격 기물입니다.', 'INVALID_PROMOTION');
    }

    let move;
    try {
      move = game.chess.move({ from, to, promotion });
    } catch {
      move = null;
    }
    if (!move) throw new GameError('둘 수 없는 수입니다.', 'ILLEGAL_MOVE');

    if (color === 'w') game.whiteClockMs += incrementMs;
    else game.blackClockMs += incrementMs;
    game.lastClockAt = timestamp;
    game.drawOfferedBy = null;
    persistGame(game);

    if (game.chess.isGameOver()) {
      if (game.chess.isCheckmate()) {
        finishGame(game, { winnerUserId: userId, reason: 'checkmate' });
      } else {
        finishGame(game, { winnerUserId: null, reason: gameOverReason(game) });
      }
    } else {
      emitActive(game);
    }

    return {
      ok: true,
      move: {
        from: move.from,
        to: move.to,
        san: move.san,
        promotion: move.promotion || null,
      },
    };
  }

  function quickQueue(userId) {
    const active = activeGameForUser(userId);
    if (active) return { activeGame: serializeActive(active, userId) };
    if (queue.has(userId)) return { queued: true, position: 1 };

    const user = db.getUserById(userId);
    requireRatedEligibility(user);
    const candidates = [...queue.values()]
      .filter((entry) => entry.userId !== userId && isOnline(entry.userId) && !activeGameForUser(entry.userId))
      .sort((a, b) => {
        const ratingDiff = Math.abs(a.rating - user.rating) - Math.abs(b.rating - user.rating);
        return ratingDiff || a.joinedAt - b.joinedAt;
      });

    const opponent = candidates[0];
    if (opponent) {
      queue.delete(opponent.userId);
      const game = createGame(userId, opponent.userId, { mode: 'quick', rated: true });
      return { matched: true, gameId: game.id };
    }

    queue.set(userId, { userId, rating: user.rating, joinedAt: now() });
    emitLobbyStats();
    return { queued: true, position: queue.size };
  }

  function cancelQueue(userId) {
    const removed = queue.delete(userId);
    emitLobbyStats();
    return { cancelled: removed };
  }

  function createInvite(userId, payload) {
    if (activeGameForUser(userId)) throw new GameError('이미 진행 중인 대국이 있습니다.', 'ALREADY_IN_GAME');
    const rated = payload?.rated === true;
    if (rated) requireRatedEligibility(db.getUserById(userId));
    clearUserLobbyState(userId);
    const code = randomInviteCode();
    const invite = {
      code,
      hostId: userId,
      rated,
      createdAt: now(),
      expiresAt: now() + config.inviteTtlMinutes * 60 * 1000,
    };
    invites.set(code, invite);
    emitLobbyStats();
    return { code, rated: invite.rated, expiresAt: invite.expiresAt };
  }

  function cancelInvite(userId) {
    let removed = false;
    for (const [code, invite] of invites) {
      if (invite.hostId === userId) {
        invites.delete(code);
        removed = true;
      }
    }
    return { cancelled: removed };
  }

  function joinInvite(userId, payload) {
    const code = cleanText(payload?.code, 6).replace(/\s/g, '').toUpperCase();
    const invite = invites.get(code);
    if (!invite || invite.expiresAt <= now()) {
      invites.delete(code);
      throw new GameError('초대 코드가 없거나 만료되었습니다.', 'INVITE_NOT_FOUND');
    }
    if (invite.hostId === userId) throw new GameError('내 초대 코드에는 참가할 수 없습니다.', 'OWN_INVITE');
    if (!isOnline(invite.hostId)) {
      invites.delete(code);
      throw new GameError('초대한 사용자가 오프라인입니다.', 'HOST_OFFLINE');
    }
    if (activeGameForUser(userId) || activeGameForUser(invite.hostId)) {
      invites.delete(code);
      throw new GameError('한쪽 사용자가 이미 대국 중입니다.', 'ALREADY_IN_GAME');
    }
    if (invite.rated) requireRatedEligibility(db.getUserById(userId));

    const game = createGame(invite.hostId, userId, { mode: 'invite', rated: invite.rated });
    invites.delete(code);
    return { matched: true, gameId: game.id, rated: game.rated };
  }

  function disconnectSession(tokenHash) {
    if (!tokenHash) return;
    for (const socket of io.sockets.sockets.values()) {
      if (socket.sessionTokenHash === tokenHash) socket.disconnect(true);
    }
  }

  function handleSocket(socket) {
    addSocket(socket);
    emitLobbyStats();

    const active = activeGameForUser(socket.user.id);
    if (active) {
      socket.join(roomForGame(active.id));
      socket.emit('game:started', serializeActive(active, socket.user.id));
      emitActive(active);
    }

    socket.on('match:queue', (_payload, ack) => {
      try {
        safeAck(ack, { ok: true, ...quickQueue(socket.user.id) });
      } catch (error) {
        safeAck(ack, { ok: false, code: error.code || 'MATCH_ERROR', message: error.message });
      }
    });

    socket.on('match:cancel', (_payload, ack) => {
      safeAck(ack, { ok: true, ...cancelQueue(socket.user.id) });
    });

    socket.on('invite:create', (payload, ack) => {
      try {
        const invite = createInvite(socket.user.id, payload);
        safeAck(ack, { ok: true, ...invite });
      } catch (error) {
        safeAck(ack, { ok: false, code: error.code || 'INVITE_ERROR', message: error.message });
      }
    });

    socket.on('invite:cancel', (_payload, ack) => {
      safeAck(ack, { ok: true, ...cancelInvite(socket.user.id) });
    });

    socket.on('invite:join', (payload, ack) => {
      try {
        safeAck(ack, { ok: true, ...joinInvite(socket.user.id, payload) });
      } catch (error) {
        safeAck(ack, { ok: false, code: error.code || 'INVITE_ERROR', message: error.message });
      }
    });

    socket.on('game:move', (payload, ack) => {
      try {
        safeAck(ack, processMove(socket.user.id, payload));
      } catch (error) {
        safeAck(ack, { ok: false, code: error.code || 'MOVE_ERROR', message: error.message });
      }
    });

    socket.on('game:sync', (payload, ack) => {
      const game = activeGames.get(cleanText(payload?.gameId, 64));
      if (!game || !participantColor(game, socket.user.id)) {
        safeAck(ack, { ok: false, code: 'GAME_NOT_FOUND', message: '대국을 찾을 수 없습니다.' });
        return;
      }
      safeAck(ack, { ok: true, game: serializeActive(game, socket.user.id) });
    });

    socket.on('game:resign', (payload, ack) => {
      try {
        const game = activeGames.get(cleanText(payload?.gameId, 64));
        if (!game || !participantColor(game, socket.user.id)) {
          throw new GameError('대국을 찾을 수 없습니다.', 'GAME_NOT_FOUND');
        }
        const result = finishGame(game, {
          winnerUserId: opponentId(game, socket.user.id),
          reason: 'resignation',
        });
        safeAck(ack, { ok: true, game: result });
      } catch (error) {
        safeAck(ack, { ok: false, code: error.code || 'RESIGN_ERROR', message: error.message });
      }
    });

    socket.on('game:draw-offer', (payload, ack) => {
      try {
        const game = activeGames.get(cleanText(payload?.gameId, 64));
        if (!game || !participantColor(game, socket.user.id)) {
          throw new GameError('대국을 찾을 수 없습니다.', 'GAME_NOT_FOUND');
        }
        if (game.drawOfferedBy === socket.user.id) {
          throw new GameError('이미 무승부를 제안했습니다.', 'DRAW_ALREADY_OFFERED');
        }
        if (game.drawOfferedBy && game.drawOfferedBy !== socket.user.id) {
          const result = finishGame(game, { winnerUserId: null, reason: 'draw_agreement' });
          safeAck(ack, { ok: true, accepted: true, game: result });
          return;
        }
        game.drawOfferedBy = socket.user.id;
        emitActive(game);
        io.to(roomForUser(opponentId(game, socket.user.id))).emit('game:notice', {
          type: 'draw-offer',
          message: '상대가 무승부를 제안했습니다.',
        });
        safeAck(ack, { ok: true, offered: true });
      } catch (error) {
        safeAck(ack, { ok: false, code: error.code || 'DRAW_ERROR', message: error.message });
      }
    });

    socket.on('game:draw-decline', (payload, ack) => {
      try {
        const game = activeGames.get(cleanText(payload?.gameId, 64));
        if (!game || !participantColor(game, socket.user.id)) {
          throw new GameError('대국을 찾을 수 없습니다.', 'GAME_NOT_FOUND');
        }
        if (!game.drawOfferedBy || game.drawOfferedBy === socket.user.id) {
          throw new GameError('받은 무승부 제안이 없습니다.', 'NO_DRAW_OFFER');
        }
        game.drawOfferedBy = null;
        emitActive(game);
        io.to(roomForUser(opponentId(game, socket.user.id))).emit('game:notice', {
          type: 'draw-declined',
          message: '상대가 무승부 제안을 거절했습니다.',
        });
        safeAck(ack, { ok: true });
      } catch (error) {
        safeAck(ack, { ok: false, code: error.code || 'DRAW_ERROR', message: error.message });
      }
    });

    socket.on('disconnect', () => {
      const activeGame = activeGameForUser(socket.user.id);
      removeSocket(socket);
      if (activeGame) emitActive(activeGame);
      emitLobbyStats();
    });
  }

  function getLobbyStats() {
    return {
      online: userSockets.size,
      searching: queue.size,
      activeGames: activeGames.size,
    };
  }

  function getGameForUser(gameId, userId) {
    const active = activeGames.get(gameId);
    if (active) {
      if (!participantColor(active, userId)) return null;
      return serializeActive(active, userId);
    }

    const row = db.getGame(gameId);
    if (!row || (row.white_user_id !== userId && row.black_user_id !== userId)) return null;
    return {
      id: row.id,
      status: row.status,
      mode: row.mode,
      rated: Boolean(row.rated),
      fen: row.fen,
      pgn: row.pgn,
      result: row.result,
      reason: row.reason,
      winnerUserId: row.winner_user_id,
      white: {
        id: row.white_user_id,
        handle: row.white_handle,
        ratingBefore: row.white_rating_before,
        ratingAfter: row.white_rating_after,
        ratingDelta: row.white_rating_delta,
      },
      black: {
        id: row.black_user_id,
        handle: row.black_handle,
        ratingBefore: row.black_rating_before,
        ratingAfter: row.black_rating_after,
        ratingDelta: row.black_rating_delta,
      },
      finishedAt: row.finished_at,
    };
  }

  restoreActiveGames();

  const clockInterval = setInterval(() => {
    const timestamp = now();
    for (const game of [...activeGames.values()]) {
      if (game.finishing) continue;
      const clocks = currentClocks(game, timestamp);
      const turnMs = game.chess.turn() === 'w' ? clocks.whiteMs : clocks.blackMs;
      if (turnMs <= 0) {
        const timedOutUser = game.chess.turn() === 'w' ? game.whiteUserId : game.blackUserId;
        try {
          finishGame(game, { winnerUserId: opponentId(game, timedOutUser), reason: 'timeout' });
        } catch (error) {
          console.error('Clock finish failed:', error);
        }
      }
    }
  }, 500);
  clockInterval.unref?.();

  const clockSyncInterval = setInterval(() => {
    for (const game of activeGames.values()) {
      io.to(roomForGame(game.id)).emit('game:clock', {
        gameId: game.id,
        turn: game.chess.turn() === 'w' ? 'white' : 'black',
        ...currentClocks(game),
        serverNow: now(),
      });
    }
  }, 5000);
  clockSyncInterval.unref?.();

  const cleanupInterval = setInterval(() => {
    const timestamp = now();
    for (const [code, invite] of invites) {
      if (invite.expiresAt <= timestamp || !isOnline(invite.hostId)) invites.delete(code);
    }
    db.cleanupSessions();
    db.cleanupUnusedGuests(now() - 30 * 24 * 60 * 60 * 1000);
  }, 60_000);
  cleanupInterval.unref?.();

  return {
    handleSocket,
    getActiveStateForUser,
    getGameForUser,
    getLobbyStats,
    disconnectSession,
    close() {
      clearInterval(clockInterval);
      clearInterval(clockSyncInterval);
      clearInterval(cleanupInterval);
    },
  };
}

module.exports = { createGameManager, GameError };
